<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\Items; // Adjust based on your Item model location
use yii\helpers\ArrayHelper;
use app\models\Units;

/* @var $this yii\web\View */
/* @var $model app\models\Stock */
/* @var $form yii\widgets\ActiveForm */

$this->title = 'Create Stock'; // Adjust title as needed
$items = ArrayHelper::map(Items::find()->all(), 'id', 'item_name');
?>

<div class="stock-form">
    <?php $form = ActiveForm::begin(); ?>

    <h2><?= Html::encode($this->title) ?></h2>

    <div class="row">
        <div class="col-md-6">
            <?= $form->field($model, 'item_id')->dropDownList($items, [
                'prompt' => 'Select an item...',
                'class' => 'form-control custom-select searchable-dropdown', // Add custom class
            ])->label('Item'); ?>
        </div>
        <div class="col-md-6">
            <?= $form->field($model, 'quantity')->textInput(['class' => 'form-control']) ?>
            <?= $form->field($model, 'unit_id')->dropDownList(
                        ArrayHelper::map(Units::find()->all(), 'id', 'name'),
                        ['prompt' => 'Select Unit']
                    )->label('Unit') ?>
        </div>
    </div>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>
</div>

<style>
    .stock-form {
        max-width: 700px;
        margin: 0 auto;
        padding: 30px;
        background-color: #f9f9f9;
        border: 1px solid #eee;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }

    .stock-form h2 {
        font-size: 24px;
        margin-bottom: 20px;
        text-align: center;
    }

    .form-control {
        padding: 12px;
        font-size: 14px;
        border: 1px solid #ddd;
        border-radius: 4px;
        transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    }

    .btn-success {
        background-color: #28a745;
        border-color: #28a745;
        color: #fff;
        padding: 12px;
        font-size: 16px;
        border-radius: 4px;
    }

    .btn-success:hover {
        background-color: #218838;
        border-color: #1e7e34;
    }

    .searchable-dropdown {
        width: 100%;
    }
</style>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    $('.searchable-dropdown').select2({
        placeholder: 'Search for an item...',
        allowClear: true,
        width: 'resolve' // Adjust width as needed
    });
});
</script>
