<?php

use app\models\Client;
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use yii\widgets\Pjax;

/* @var $this yii\web\View */
/* @var $model app\models\Invoice */
/* @var $form yii\widgets\ActiveForm */
$this->title = "Add Invoice";
?>
<!-- Bootstrap Icons CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

<style>
    body {
        font-weight: 400;
    }

    .quotation-form {
        padding: 20px;
        background-color: #f8f9fa;
        border: 1px solid #dee2e6;
        border-radius: 5px;
    }

    .form-control:focus {
        box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
    }

    .panel-heading {
        cursor: pointer;
    }
</style>

<div class="quotation-form">
    <?php $form = ActiveForm::begin(['action' => ['quotation/save-quotation']]); ?>

    <div class="row mb-3">
        <div class="col-md-3">
            <?php Pjax::begin(['id' => 'clients']); ?>
            <?php
            $clients = Client::find()->all();
            $client_array = ArrayHelper::map($clients, 'client_id', 'companyname');

            echo $form->field($model, 'client_id')->dropDownList($client_array, ['prompt' => 'Select client', 'class' => 'form-control']);
            ?>
            <?php Pjax::end(); ?>
        </div>
        <div class="col-md-2">
            <?= $form->field($model, 'quotation_number')->textInput(['maxlength' => true, 'class' => 'form-control'])->input('text') ?>
            <p><i>Auto-generated if left empty</i></p>
        </div>
        <div class="col-md-3">
            <?= $form->field($model, 'quotation_date')->widget(\yii\jui\DatePicker::class, [
                'language' => 'en',
                'dateFormat' => 'yyyy-MM-dd',
                'options' => ['class' => 'form-control', 'placeholder' => 'Select issue date ...'],
            ]) ?>
        </div>
        <div class="col-md-2">
            <?= $form->field($model, 'expiry_date')->widget(\yii\jui\DatePicker::class, [
                'language' => 'en',
                'dateFormat' => 'yyyy-MM-dd',
                'options' => ['class' => 'form-control', 'placeholder' => 'Select Expiry date ...'],
            ]) ?>
        </div>
        <div class="col-md-2">
            <?= $form->field($model, 'currency')->dropdownList(['INR' => "Indian Rupees", 'USD' => "US Dollar"], ['class' => 'form-control']) ?>
        </div>
    </div>

    <table class="table table-bordered content-table">
        <thead class="thead-light">
            <tr>
                <th>#</th>
                <th>CONTENT</th>
                <th>UNIT PRICE</th>
                <th>QTY</th>
                <th>TOTAL</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td>
                    <input type="text" class="form-control item-input" placeholder="Items">
                    <input type="text" class="form-control description-input mt-2" placeholder="Description">
                </td>
                <td><input type="text" class="form-control cost-input" value="0"></td>
                <td><input type="text" class="form-control qty-input" value="1"></td>
                <td class="amount">0</td>
                <td>
                    <button type="button" class="btn btn-outline-primary add-item-btn"><i class="bi bi-plus-lg"></i></button>
                </td>
            </tr>
            <tr>
                <td colspan="3"></td>
                <td>
                    <?= $form->field($model, 'discount')->textInput(['class' => 'form-control'])->label("Discount %") ?>
                </td>
                <td class="discount-value">0</td>
                <td></td>
            </tr>
            <tr>
                <td colspan="3"></td>
                <td>
                    <?= $form->field($model, 'gst')->textInput(['class' => 'form-control'])->label("GST %") ?>
                </td>
                <td class="gst-value">0</td>
                <td></td>
            </tr>
            <tr>
                <td colspan="3"></td>
                <td><b>Subtotal</b></td>
                <td class="subtotal">0</td>
                <td></td>
            </tr>
            <tr>
                <td colspan="3"></td>
                <td><b>TOTAL</b></td>
                <td class="total">0</td>
                <td></td>
            </tr>
        </tbody>
    </table>

    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title"><b>Additional Fields</b></h3>
        </div>
        <div class="panel-body">
            <div class="row mb-3">
                <div class="col-md-6">
                    <p><i>Any additional fields to be added in the invoice can be added by the following fields</i></p>
                </div>
                <div class="col-md-6 text-right">
                    <button type="button" class="btn btn-outline-primary field-btn"><i class="bi bi-plus-lg"></i> Add Field</button>
                </div>
            </div>
            <div class="fields">
                <div class="row field-template">
                    <div class="col-md-3">
                        <p>Field Label
                            <input type="text" name="Quotation[field_label][]" class="form-control">
                        </p>
                    </div>
                    <div class="col-md-3">
                        <p>Field Value
                            <input type="text" name="Quotation[field_value][]" class="form-control">
                        </p>
                    </div>
                    <div class="col-md-1 field-remove">
                        <p><br>
                            <button type="button" class="btn btn-outline-danger"><i class="bi bi-trash"></i></button>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    

    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title"><b>Print Settings</b></h3>
        </div>
        <div class="panel-body">
            <div class="row">
                <div class="col-md-2">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="Quotation[print_setting][]" id="hide_qty" value="hide_qty">
                        <label class="form-check-label" for="hide_qty">
                            Hide Qty column
                        </label>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="Quotation[print_setting][]" id="hide_unit_price" value="hide_unit_price">
                        <label class="form-check-label" for="hide_unit_price">
                            Hide unit price column
                        </label>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="Quotation[print_setting][]" id="hide_authorized_signature" value="hide_authorized_signature">
                        <label class="form-check-label" for="hide_authorized_signature">
                            Hide authorized signature
                        </label>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="Quotation[print_setting][]" id="hide_logo" value="hide_logo">
                        <label class="form-check-label" for="hide_logo">
                            Hide Logo
                        </label>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="Quotation[print_setting][]" id="hide_company_name" value="hide_company_name">
                        <label class="form-check-label" for="hide_company_name">
                            Hide company name
                        </label>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>
</div>
<input type="hidden" name="Quotation[quotation_number]">
<?php 

$script = <<< JS
        $(document).ready(function(){
            let total = 0;
            let item_amount = 0;
            let discount_amount = 0;
            let gst_amount = 0;
            let selected_ele;
            $(".add-item-btn").click(function(){
                var item = $(".item-input").val();
                var description = $(".description-input").val();
                var cost = $(".cost-input").val();
                var qty = $(".qty-input").val();
                var amount = 0;
                if(!isNaN(cost) && !isNaN(qty)){
                    amount = parseFloat((Number(cost) * parseFloat(qty))).toFixed(2);
                }else{
                    amount = 0;
                }
                
                var tr = '\
                <tr class=\'select-row\'>\
                    <td>#</td>\
                    <td>\
                        <p>'+item+'<br><i>'+description+'</i></p>\
                    </td>\
                    <td>'+cost+'</td>\
                    <td>'+qty+'</td>\
                    <td class=\'amount\'>'+amount+'</td>\
                    <td>\
                        <a  style="padding: 3px 6px;" class="del-btn  btn btn-default"><i class="bi bi-trash"></i></a>\
                        <a style="padding: 3px 6px; display: none;" class="up-btn btn btn-default"><i class="bi bi-arrow-up"></i></a>\
                        <a style="padding: 3px 6px; display: none;" class="down-btn btn btn-default"><i class="bi bi-arrow-down"></i></a>\
                        <input type="hidden" value=\''+qty+'\' name="Quotation[qty][]">\
                        <input type="hidden" value=\''+item+'\' name="Quotation[item][]">\
                        <input type="hidden" value=\''+description+'\' name="Quotation[description][]">\
                        <input type="hidden" value=\''+cost+'\' name="Quotation[price][]">\
                    </td>\
                </tr>';
                $(".item-input").val("");
                $(".description-input").val("");
                $(".cost-input").val("0");
                $(".qty-input").val("1");
                $(".content-table tr").eq(-5).after(tr);
                item_amount = parseFloat(item_amount) + parseFloat(amount);
                calculateDiscount();
            });

            $("#quotation-discount").keyup(function(){
                calculateDiscount();
            });
            $("#quotation-gst").keyup(function(){
                calculateGST();
            });

            $('body').click(function(){
                $(".select-row").css('background-color', 'white');
                $(".down-btn").css('display', 'none');
                $(".up-btn").css('display', 'none');
            });

            $(document).on("click",'.del-btn', function(e){
                item_amount -= parseFloat($(this).parent().parent().find(".amount").html());
                calculateDiscount();
                $(this).parent().parent().remove();
            });
            $(document).on("click",'.down-btn', function(e){
                goDown($(this));
            });
            $(document).on("click",'.up-btn', function(e){
                goUp($(this));
            });
            $(document).on("click",'.select-row', function(e){
                $(".select-row").css('background-color', 'white');
                $(this).find(".down-btn").css('display', 'inline');
                $(this).find(".up-btn").css('display', 'inline');
                $(this).css('background-color', '#fff799');
                selected_ele = $(this);
            });
            $(document).keydown(function(e) {
                if(e.which == 38){
                    goUp($(selected_ele).find(".up-btn"));
                }
                if(e.which == 40){
                   goDown($(selected_ele).find(".down-btn"));
                }
                if (e.key == "Escape") { 
                    $(".down-btn").css('display', 'none');
                    $(".up-btn").css('display', 'none');
                    $(".select-row").css('background-color', 'white');
                } 
                
            });
            function goDown(ele){
                var index= $(ele).parent().parent().index();
                if(($(".content-table").children().children().last().index()-(index+1) > 3)){
                    $(ele).parent().parent().insertAfter($(ele).parent().parent().parent().find("tr").eq(index+1));
                }
            }
            function goUp(ele){
                var index= $(ele).parent().parent().index();
                if((index > 2)){
                    $(ele).parent().parent().insertBefore($(ele).parent().parent().parent().find("tr").eq(index-1));
                }
            }

            function calculateDiscount(){
                let discount = $("#quotation-discount").val();
                discount = discount / 100;
                discount_amount = parseFloat((discount * item_amount)).toFixed(2);
                //console.log(discount_amount);
                $(".discount-value").html(discount_amount);
                $(".subtotal").html(parseFloat((item_amount - discount_amount)).toFixed(2));
                $(".total").html(parseFloat(((item_amount - discount_amount) + gst_amount)).toFixed(2));
                $(".total-input").val(parseFloat(((item_amount - discount_amount) + gst_amount)).toFixed(2));
                calculateGST();
            }

            function calculateGST(){
                let gst = parseFloat($("#quotation-gst").val());
                console.log(discount_amount);
                gst = gst / 100;
                gst_amount = parseFloat(((item_amount - discount_amount) * gst)).toFixed(2);
                console.log( gst_amount);
                $(".gst-value").html(gst_amount);
                $(".total").html(parseFloat((item_amount - discount_amount)+ Number(gst_amount)).toFixed(2));
                $(".total-input").val(parseFloat((item_amount - discount_amount)+ Number(gst_amount)).toFixed(2));
            }
            $('.panel-heading').next().hide();
            $(".panel-heading").click(function(){
                $(this).next().slideToggle();
            });
            $(".field-btn").click(function(){
                div = '<div class="row field-template">\
                        <div class="col-md-3">\
                            <p>Field Label\
                            <input type="text" name="Quotation[field_label][]" class="form-control">\
                            </p>\
                        </div>\
                        <div class="col-md-3">\
                            <p>Field Value\
                            <input type="text" name="Quotation[field_value][]" class="form-control">\
                            </p>\
                        </div>\
                        <div class="col-md-1 field-remove">\
                            <p><br>\
                                <a style="color: red;"  class="btn btn-default"><span class="glyphicon glyphicon-remove"></span></a>\
                            </p>\
                        </div>\
                    </div>';
                $(".fields").append(div);
            });
        });
        $(document).on("click",".field-remove", function(e){
            $(this).parent().remove();
        });
JS;
    $this->registerJS($script);
?>