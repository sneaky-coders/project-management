<!-- Preloader -->
<div class="preloader">
    <div class="d-table">
        <div class="d-tablecell">
            <span class="loader">
                <span class="loader-inner"></span>
            </span>
        </div>
    </div>
</div>