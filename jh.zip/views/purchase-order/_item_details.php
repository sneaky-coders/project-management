<?php foreach ($items as $item): ?>
    <div class="item-detail">
        <h4><?= Html::encode($item->item_name) ?></h4>
        <p>SKU: <?= Html::encode($item->sku) ?></p>
        <p>Cost Price: <?= Html::encode($item->cost_price) ?></p>
        <p>Selling Price: <?= Html::encode($item->selling_price) ?></p>
        <p>Reorder Level: <?= Html::encode($item->reorder_level) ?></p>
    </div>
<?php endforeach; ?>
