<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use app\models\Vendor;
use app\models\Items;
use app\models\Units;

/* @var $this yii\web\View */
/* @var $model app\models\PurchaseOrder */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h1 class="card-title">Raise Purchase Order</h1>

                    <?php $form = ActiveForm::begin([
                        'options' => ['class' => 'modern-form'],
                    ]); ?>

                    <div class="row">
                        <div class="col-md-6">
                            <?= $form->field($model, 'po_number')->textInput(['maxlength' => true, 'placeholder' => 'Enter PO Number'])->label('Purchase Order Number') ?>
                        </div>
                        <div class="col-md-6">
                            <?= $form->field($model, 'po_date')->widget(\yii\jui\DatePicker::classname(), [
                                'dateFormat' => 'yyyy-MM-dd',
                                'options' => ['class' => 'form-control', 'placeholder' => 'Select PO Date']
                            ])->label('Purchase Order Date') ?>
                        </div>
                    </div>

                    <?= $form->field($model, 'vendor_id')->dropDownList(
                        ArrayHelper::map(Vendor::find()->all(), 'vendor_id', 'name'),
                        ['prompt' => 'Select Vendor', 'onchange' => 'fetchItemsByVendor(this.value)']
                    )->label('Vendor') ?>

                    <?= $form->field($model, 'reference')->textInput(['maxlength' => true, 'placeholder' => 'Enter Reference'])->label('Purchase Order Reference') ?>

                    <hr>

                    <h2 class="section-title">Items</h2>

                    <!-- Section to display item list of the selected vendor -->
                    <div id="items-list" style="margin-bottom: 20px;">
                        <!-- Items will be displayed here -->
                    </div>

                    <!-- Section to display item dropdown and other fields -->
                    <div class="row">
                        <div class="col-md-6">
                            <?= $form->field($model, 'item_id')->dropDownList(
                                [], // Initially empty; filled with JavaScript
                                ['prompt' => 'Select Item']
                            )->label('Item Name') ?>
                        </div>
                        <div class="col-md-3">
                            <?= $form->field($model, 'unit_id')->dropDownList(
                                ArrayHelper::map(Units::find()->all(), 'id', 'name'),
                                ['prompt' => 'Select Unit']
                            )->label('Unit') ?>
                        </div>
                        <div class="col-md-3">
                            <?= $form->field($model, 'qty')->textInput(['placeholder' => 'Quantity'])->label('Quantity') ?>
                        </div>
                    </div>

                    <?= $form->field($model, 'payment_terms')->dropDownList(
                        ['NET 30' => 'NET 30', 'NET 60' => 'NET 60', 'COD' => 'COD'],
                        ['prompt' => 'Select Payment Terms']
                    )->label('Payment Terms') ?>

                    <?= $form->field($model, 'delivery_date')->widget(\yii\jui\DatePicker::classname(), [
                        'dateFormat' => 'yyyy-MM-dd',
                        'options' => ['class' => 'form-control', 'placeholder' => 'Select Delivery Date']
                    ]) ?>

                    <div class="form-group">
                        <?= Html::submitButton('Submit', ['class' => 'btn btn-primary']) ?>
                    </div>

                    <?php ActiveForm::end(); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* styles.css */

    .container {
        margin-top: 30px;
    }

    .card {
        border: none;
        border-radius: 8px;
        background-color: #fff;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
    }

    .card-title {
        font-size: 2.5rem;
        margin-bottom: 1.5rem;
        font-weight: 600;
        color: #333;
        text-align: center;
    }

    .section-title {
        font-size: 1.8rem;
        margin-top: 2rem;
        margin-bottom: 1.5rem;
        font-weight: 500;
        color: #333;
    }

    .form-group {
        margin-bottom: 2rem;
    }

    .control-label {
        font-weight: bold;
        color: #666;
    }

    .modern-form .form-control {
        border: 1px solid #ccc;
        border-radius: 5px;
        transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    }

    .modern-form .form-control:focus {
        border-color: #6cb2eb;
        outline: 0;
        box-shadow: 0 0 0 0.2rem rgba(108, 178, 235, 0.25);
    }

    .btn-primary {
        background-color: #007bff;
        border-color: #007bff;
        font-weight: bold;
        padding: 0.75rem 1.5rem;
        transition: background-color 0.15s ease-in-out, border-color 0.15s ease-in-out;
    }

    .btn-primary:hover {
        background-color: #0056b3;
        border-color: #0056b3;
    }
</style>

<script>
    function fetchItemsByVendor(vendorId) {
        var itemsList = document.getElementById('items-list');
        var itemDropdown = document.querySelector('[name="PurchaseOrder[item_id]"]');

        if (!vendorId) {
            itemsList.innerHTML = '';
            itemDropdown.innerHTML = '<option value="">Select Item</option>';
            return;
        }

        // Display a preloader
        itemsList.innerHTML = '<p>Loading...</p>';

        // Fetch items from the server
        fetch('/index.php?r=purchase-order/get-items-by-vendor&vendor_id=' + vendorId)
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    itemsList.innerHTML = '<p>' + data.error + '</p>';
                    itemDropdown.innerHTML = '<option value="">Select Item</option>';
                    return;
                }

                // Clear preloader and display items
                itemsList.innerHTML = '<ul>' + data.map(item => `<li>${item.name} (SKU: ${item.sku})</li>`).join('') + '</ul>';
                
                // Update item dropdown
                itemDropdown.innerHTML = '<option value="">Select Item</option>' +
                    data.map(item => `<option value="${item.id}">${item.name}</option>`).join('');
            })
            .catch(error => {
                itemsList.innerHTML = '<p>Error fetching items.</p>';
                console.error('Error fetching items:', error);
            });
    }
</script>
