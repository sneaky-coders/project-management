<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $searchModel app\models\SearchInvoice */
/* @var $dataProvider yii\data\ActiveDataProvider */
/* @var $payment_status string */
/* @var $overall float */
/* @var $filter_option string */
/* @var $start_date string */
/* @var $end_date string */

$this->title = 'Sales Report';
$this->params['breadcrumbs'][] = $this->title;

// CSS styles for improved layout
$this->registerCss('
    .filter-form {
        background-color: #f9f9f9;
        padding: 15px;
        border: 1px solid #ddd;
        border-radius: 5px;
        margin-bottom: 20px;
    }
    .btn-filter {
        margin-top: 24px;
    }
    .total-amount {
        background-color: #e9ecef;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 5px;
        margin-bottom: 20px;
    }
');

?>

<div class="invoice-report">

    <h1><?= Html::encode($this->title) ?></h1>

    <!-- Filter Form -->
    <div class="filter-form">
        <?php $form = ActiveForm::begin(['method' => 'get', 'options' => ['class' => 'row']]); ?>

        <div class="col-md-3">
            <?= Html::dropDownList('filter_option', $filter_option, [
                'all' => 'All Records',
                'date_status' => 'Date Range & Payment Status',
            ], [
                'id' => 'filter_option', // Add an ID for JavaScript use
                'class' => 'form-control',
                'prompt' => 'Select filter option ...'
            ]) ?>
        </div>

        <!-- Start Date Input -->
        <div class="col-md-3" id="date-range" style="display: <?= $filter_option === 'date_status' ? 'block' : 'none' ?>;">
            <?= Html::input('date', 'start_date', $start_date, ['class' => 'form-control', 'placeholder' => 'Start Date']) ?>
        </div>

        <!-- End Date Input -->
        <div class="col-md-3" id="date-range-end" style="display: <?= $filter_option === 'date_status' ? 'block' : 'none' ?>;">
            <?= Html::input('date', 'end_date', $end_date, ['class' => 'form-control', 'placeholder' => 'End Date']) ?>
        </div>

        <!-- Payment Status Dropdown -->
        <div class="col-md-3">
            <?= Html::dropDownList('payment_status', $payment_status, [
                '' => 'All',
                '1' => 'Paid',
                '0' => 'Not Paid',
            ], [
                'class' => 'form-control',
                'prompt' => 'Select payment status ...'
            ]) ?>
        </div>

        <!-- Filter Button -->
        <div class="col-md-3">
            <?= Html::submitButton('Filter', ['class' => 'btn btn-primary btn-filter']) ?>
        </div>

        <!-- Print Report Button -->
        <div class="col-md-3">
            <?= Html::a('Print Report', ['printpdf', 'filter_option' => $filter_option, 'start_date' => $start_date, 'end_date' => $end_date, 'payment_status' => $payment_status], ['class' => 'btn btn-success btn-filter']) ?>
        </div>

        <?php ActiveForm::end(); ?>
    </div>

    <!-- Total Amount -->
    <div class="total-amount">
        <div class="row">
            <div class="col-md-6">
                <?php if ($overall !== null): ?>
                    <p><strong>Total Amount:</strong> INR <?= Yii::$app->formatter->asDecimal($overall) ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Invoice Table -->
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'options' => ['class' => 'table-responsive'], // Ensure the table is responsive
        'tableOptions' => ['class' => 'table table-striped'], // Add Bootstrap table classes
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            'invoice_number',
            [
                'attribute' => 'invoice_date',
                'format' => ['date', 'php:d M Y'],
            ],
            [
                'attribute' => 'client.companyname',
                'label' => 'Client Name',
            ],
            [
                'attribute' => 'total',
                'format' => ['currency', 'INR'],
            ],
            [
                'attribute' => 'payment_status',
                'value' => function ($model) {
                    return $model->payment_status == 1 ? 'Paid' : 'Not Paid';
                },
                'filter' => [
                    '1' => 'Paid',
                    '0' => 'Not Paid',
                ],
            ],
        ],
    ]); ?>

</div>

<?php
// JavaScript to toggle visibility of date inputs based on filter option
$script = <<< JS
    $('#filter_option').change(function(){
        var option = $(this).val();
        if (option === 'date_status') {
            $('#date-range').show();
            $('#date-range-end').show(); // Show end date input
        } else {
            $('#date-range').hide();
            $('#date-range-end').hide(); // Hide end date input
        }
    }).change(); // Trigger change event initially
JS;
$this->registerJs($script);
?>
