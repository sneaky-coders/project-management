<?php

namespace app\controllers;

use Yii;
use app\models\PurchaseOrder;
use app\models\SearchPurchaseOrder;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use app\models\Items;

/**
 * PurchaseOrderController implements the CRUD actions for PurchaseOrder model.
 */
class PurchaseOrderController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all PurchaseOrder models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new SearchPurchaseOrder();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single PurchaseOrder model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        $model = $this->findModel($id);
        // Assuming you have a method to get related items
        $items = $model->getItem(); // Adjust according to your actual method
    
        return $this->render('view', [
            'model' => $model,
            'items' => $items,
        ]);
    }

    public function actionGetItems($vendor_id)
    {
        $items = Item::find()
            ->join('INNER JOIN', 'item_vendor', 'vendor.item_id = items.id')
            ->where(['item_vendor.vendor_id' => $vendor_id])
            ->all();

        $options = '<option value="">Select Item</option>';
        foreach ($items as $item) {
            $options .= '<option value="' . $item->id . '">' . Html::encode($item->item_name) . '</option>';
        }

        return $options;
    }

    public function actionGetItemsByVendor($vendor_id)
    {
        Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
    
        // Validate vendor_id
        if (!is_numeric($vendor_id)) {
            return $this->asJson(['error' => 'Invalid vendor_id']);
        }
    
        $items = Items::find()->where(['vendor_id' => $vendor_id])->all();
        if (empty($items)) {
            return $this->asJson(['error' => 'No items found for the selected vendor']);
        }
    
        // Debug output
        Yii::info('Items found: ' . print_r($items, true), __METHOD__);
    
        $itemList = [];
        foreach ($items as $item) {
            $itemList[] = [
                'id' => $item->id,
                'name' => $item->item_name,
                'sku' => $item->sku,
                'cost_price' => $item->cost_price,
                'selling_price' => $item->selling_price,
                'unit_id' => $item->unit_id,
                'upc' => $item->upc,
                'ean' => $item->ean,
                'isbn' => $item->isbn,
                'reorder_level' => $item->reorder_level,
            ];
        }
    
        return $this->asJson($itemList);
    }
    

    

    


    /**
     * Creates a new PurchaseOrder model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new PurchaseOrder();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->po_id]);
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing PurchaseOrder model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->po_id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    public function actionBill($id)
    {
        $model = PurchaseOrder::findOne($id);

        if ($model === null) {
            throw new NotFoundHttpException('The requested page does not exist.');
        }

        return $this->render('bill', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing PurchaseOrder model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the PurchaseOrder model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return PurchaseOrder the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = PurchaseOrder::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
