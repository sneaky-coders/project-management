<?php

namespace app\controllers;

use app\models\Client;
use Yii;
use app\models\Quotation;
use app\models\Purchase;
use app\models\SearchQuotation;
use app\models\SearchPurchase;
use DateTime;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\data\ActiveDataProvider;
use Mpdf\Mpdf;


/**
 * InvoiceController implements the CRUD actions for Invoice model.
 */
class QuotationController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Invoice models.
     * @return mixed
     */
    public function actionIndex()
    {
       
        $searchModel = new SearchQuotation();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    
    
   

    /**
     * Displays a single Invoice model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        if(!Yii::$app->user->isGuest){
            $model = $this->findModel($id);
            $id = Yii::$app->user->identity->user_id;
            if($model->user_id == $id){
                return $this->render('view', [
                    'model' => $model,
                ]);
            }else{
                throw new \yii\web\ForbiddenHttpException;
            } 
        }else{
            throw new \yii\web\ForbiddenHttpException;
        } 
    }



    /**
     * Creates a new Invoice model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        if(!Yii::$app->user->isGuest){
            $model = new Quotation();
            $client = new  Client();
            if ($client->load(Yii::$app->request->post())) {
                Yii::$app->session->setFlash('success', 'Quotation created successfully.');
                return $this->redirect(['site/index']);
                $client->save(false);
                $client = new  Client();
            }

            return $this->render('create', [
                'model' => $model,
                'client' => $client,
            ]);
        }else{
            throw new \yii\web\ForbiddenHttpException;
        } 
    }

   




    public function actionSaveQuotation()
    {
        if(!Yii::$app->user->isGuest){
            $model = new Quotation();
            if ($model->load(Yii::$app->request->post())) {
                $model->user_id = Yii::$app->user->identity->user_id;
                $contentArray = Array();
                $notesArray = Array();
                $fieldArray = Array();
                $settingArray = Array();
                if(is_array($model->qty)){
                    foreach($model->qty as $key => $value){
                        $tmp = Array();
                        array_push($tmp, $model->item[$key]);
                        array_push($tmp, $model->description[$key]);
                        array_push($tmp, $model->price[$key]);
                        array_push($tmp, $model->qty[$key]);
                        array_push($contentArray, $tmp);
                        array_push($notesArray, $tmp);
                    }
                }
                $model->content = json_encode($contentArray);
                $model->notes = json_encode($notesArray);
                if(is_array($model->field_value)){
                    foreach($model->field_value as $key => $value){
                        if( $model->field_label[$key] != "" ||  $model->field_value[$key] !=""){
                            $tmp = Array();
                            array_push($tmp, $model->field_label[$key]);
                            array_push($tmp, $model->field_value[$key]);
                            array_push($fieldArray, $tmp);
                        }
                    }
                }
                $model->additional_fields = json_encode($fieldArray);
                if(is_array($model->print_setting)){
                    foreach($model->print_setting as $key => $value){
                        //$model->print_setting[$key]. "<br>";
                        array_push($settingArray,  $value);
                    }
                }
                $model->quotation_option = json_encode($settingArray);
                $model->save();
                if($model->quotation_number == ""){
                    $dt =  DateTime::createFromFormat('!d/m/Y', date("d/m/Y"));
                    echo strtoupper($dt->format('M')); # 24 DEC
                    $model->quotation_number = "QUO/".strtoupper($dt->format('M')).$dt->format("y")."/".$model->quotation_id;
                    $model->save();
                }
                return $this->redirect(['view', 'id' => $model->quotation_id]);
            }
        }else{
            throw new \yii\web\ForbiddenHttpException;
        } 
    }

    /**
     * Updates an existing Invoice model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        if(!Yii::$app->user->isGuest){
            $model = $this->findModel($id);
            $id = Yii::$app->user->identity->user_id;
            if($model->user_id == $id){
                $client = new  Client();
                if ($client->load(Yii::$app->request->post())) {
                    $client->user_id = Yii::$app->user->identity->user_id;
                    $client->save(false);
                    $client = new  Client();
                }
                return $this->render('update', [
                    'model' => $model,
                    'client' => $client,
                ]);
            }else{
                throw new \yii\web\ForbiddenHttpException;
            } 
        }else{
            throw new \yii\web\ForbiddenHttpException;
        } 
    }

    public function actionUpdateQuotation()
    {
        if(!Yii::$app->user->isGuest){
            $model = new Quotation();
            if ($model->load(Yii::$app->request->post())) {
                
                $quotation = Quotation::findOne($model->quotation_id);
                $model->user_id = Yii::$app->user->identity->user_id;
                $contentArray = Array();
                $notesArray = Array();
                $fieldArray = Array();
                $settingArray = Array();
                $quotation->gst = $model->gst;
                $quotation->discount = $model->discount;
                $quotation->quotation_date = $model->quotation_date;
                $quotation->expiry_date = $model->expiry_date;
                $quotation->quotation_number = $model->quotation_number;
                $quotation->currency = $model->currency;
                $quotation->client_id = $model->client_id;
                if(is_array($model->qty)){
                    foreach($model->qty as $key => $value){
                        $tmp = Array();
                        array_push($tmp, $model->item[$key]);
                        array_push($tmp, $model->description[$key]);
                        array_push($tmp, $model->price[$key]);
                        array_push($tmp, $model->qty[$key]);
                        array_push($contentArray, $tmp);
                        array_push($notesArray, $tmp);
                    }
                }
                $quotation->content = json_encode($contentArray);
                $quotation->notes = json_encode($notesArray);
                if(is_array($model->field_value)){
                    foreach($model->field_value as $key => $value){
                        $tmp = Array();
                        array_push($tmp, $model->field_label[$key]);
                        array_push($tmp, $model->field_value[$key]);
                        array_push($fieldArray, $tmp);
                    }
                }
                $quotation->additional_fields = json_encode($fieldArray);
                if(is_array($model->print_setting)){
                    foreach($model->print_setting as $key => $value){
                        //$model->print_setting[$key]. "<br>";
                        array_push($settingArray,  $value);
                    }
                }
                $quotation->quotation_option = json_encode($settingArray);
                $quotation->save();
                return $this->redirect(['view', 'id' => $model->quotation_id]);
            }
        }else{
            throw new \yii\web\ForbiddenHttpException;
        } 
    }


    /**
     * Deletes an existing Invoice model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionPrint()
    {
        if(!Yii::$app->user->isGuest){
            $id = Yii::$app->request->get("id");
            $print_layout = Yii::$app->request->get("layout");
            $model = $this->findModel($id);
            $id = Yii::$app->user->identity->user_id;
            if($model->user_id == $id){
                $this->layout = 'print';
                return $this->render($print_layout, [
                    'model' => $model,
                ]);
            }else{
                throw new \yii\web\ForbiddenHttpException;
            } 
        }else{
            throw new \yii\web\ForbiddenHttpException;
        } 
    }
    public function actionDelete($id)
    {
        if(!Yii::$app->user->isGuest){
            $model = $this->findModel($id);    
            $user_id = Yii::$app->user->identity->user_id;
            if($model->user_id == $user_id){
                $model->delete();
                return $this->redirect(['index']);
            }else{
                throw new \yii\web\ForbiddenHttpException;
            } 
        }else{
            throw new \yii\web\ForbiddenHttpException;
        } 
    }

    /**
     * Finds the Invoice model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Invoice the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Quotation::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
