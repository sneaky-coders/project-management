<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "purchase_order".
 *
 * @property int $po_id
 * @property int $vendor_id
 * @property string $po_number
 * @property string $reference
 * @property string $po_date
 * @property string $delivery_date
 * @property string $payment_terms
 * @property int $item_id
 * @property int $unit_id
 * @property int $qty
 * @property string $created_at
 * @property string $updated_at
 *
 * @property Vendor $vendor
 * @property Items $item
 * @property Units $unit
 */
class PurchaseOrder extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'purchase_order';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['vendor_id', 'po_number', 'reference', 'po_date', 'delivery_date', 'payment_terms', 'item_id', 'unit_id', 'qty'], 'required'],
            [['vendor_id', 'item_id', 'unit_id', 'qty'], 'integer'],
            [['po_date', 'delivery_date', 'created_at', 'updated_at'], 'safe'],
            [['po_number', 'reference', 'payment_terms'], 'string', 'max' => 200],
            [['vendor_id'], 'exist', 'skipOnError' => true, 'targetClass' => Vendor::className(), 'targetAttribute' => ['vendor_id' => 'vendor_id']],
            [['item_id'], 'exist', 'skipOnError' => true, 'targetClass' => Items::className(), 'targetAttribute' => ['item_id' => 'id']],
            [['unit_id'], 'exist', 'skipOnError' => true, 'targetClass' => Units::className(), 'targetAttribute' => ['unit_id' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'po_id' => 'Po ID',
            'vendor_id' => 'Vendor ID',
            'po_number' => 'Po Number',
            'reference' => 'Reference',
            'po_date' => 'Po Date',
            'delivery_date' => 'Delivery Date',
            'payment_terms' => 'Payment Terms',
            'item_id' => 'Item ID',
            'unit_id' => 'Unit ID',
            'qty' => 'Qty',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * Gets query for [[Vendor]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getVendor()
    {
        return $this->hasOne(Vendor::className(), ['vendor_id' => 'vendor_id']);
    }

    /**
     * Gets query for [[Item]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getItem()
    {
        return $this->hasOne(Items::className(), ['id' => 'item_id']);
    }

    /**
     * Gets query for [[Unit]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getUnit()
    {
        return $this->hasOne(Units::className(), ['id' => 'unit_id']);
    }



 
}
