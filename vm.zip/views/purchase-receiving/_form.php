<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use yii\helpers\Url;
use app\models\PurchaseOrder;

/* @var $this yii\web\View */
/* @var $model app\models\PurchaseReceiving */
/* @var $form yii\widgets\ActiveForm */

$this->registerCss("
    .purchase-receiving-form {
        max-width: 1200px;
        margin: 40px auto;
        padding: 40px;
        background-color: #ffffff;
        border: 1px solid #e0e0e0;
        border-radius: 8px;
        box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
    }
    .purchase-receiving-form h2 {
        margin-bottom: 30px;
        color: #2c3e50;
        font-family: 'Roboto', sans-serif;
        font-size: 28px;
        font-weight: 700;
        text-align: center;
    }
    .form-group {
        margin-bottom: 20px;
    }
    .form-group label {
        font-weight: 600;
        font-family: 'Roboto', sans-serif;
        color: #34495e;
    }
    .form-control {
        border: 1px solid #ced4da;
        border-radius: 5px;
        padding: 10px;
        font-family: 'Roboto', sans-serif;
        font-size: 16px;
    }
    .form-control:focus {
        border-color: #3498db;
        box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
    }
    #purchase-order-details {
        margin-top: 30px;
        padding: 20px;
        background-color: #f8f9fa;
        border: 1px solid #e0e0e0;
        border-radius: 5px;
        font-family: 'Roboto', sans-serif;
    }
    #purchase-order-details p {
        margin: 0 0 15px;
        color: #2c3e50;
    }
    #purchase-order-details ul {
        padding-left: 20px;
    }
    #purchase-order-details li {
        list-style: disc;
        margin-bottom: 5px;
    }
    .btn-success {
        background-color: #28a745;
        border-color: #28a745;
        font-family: 'Roboto', sans-serif;
        font-size: 16px;
        padding: 12px 20px;
        border-radius: 5px;
        transition: background-color 0.3s ease;
    }
    .btn-success:hover {
        background-color: #218838;
        border-color: #1e7e34;
    }
");

?>

<div class="purchase-receiving-form">

    <h2>Purchase Receiving Form</h2>

    <?php $form = ActiveForm::begin([
        'options' => ['class' => 'form-horizontal'],
        'fieldConfig' => [
            'template' => "<div class=\"form-group row\"><div class=\"col-md-4 col-form-label text-md-right\">{label}</div><div class=\"col-md-8\">{input}\n{error}</div></div>",
            'labelOptions' => ['class' => 'col-form-label'],
        ],
    ]); ?>

    <div class="row">
        <div class="col-md-6">
            <?= $form->field($model, 'purchase_id')->dropDownList(
                ArrayHelper::map(PurchaseOrder::find()->all(), 'po_id', 'po_number'),
                ['prompt' => 'Select a purchase order ...', 'class' => 'form-control']
            ) ?>
        </div>
        <div class="col-md-6">
            <?= $form->field($model, 'received_qty')->textInput(['maxlength' => true, 'placeholder' => 'Enter Received Quantity', 'class' => 'form-control']) ?>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <?= $form->field($model, 'status')->dropDownList([
                'Pending' => 'Pending',
                'Completed' => 'Completed',
                'Cancelled' => 'Cancelled'
            ], ['prompt' => 'Select a status ...', 'class' => 'form-control']) ?>
        </div>
    </div>

    <div id="purchase-order-details" class="col-md-12"></div>

    <div class="form-group row">
        <div class="col-md-12 text-center">
            <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
        </div>
    </div>

    <?php ActiveForm::end(); ?>

</div>

<?php
$this->registerJs('
    $("#purchasereceiving-purchase_id").on("change", function() {
        var purchaseId = $(this).val();
        if(purchaseId) {
            $.ajax({
                url: "' . Url::to(['purchase-order/get-purchase-order-data']) . '",
                data: {id: purchaseId},
                success: function(response) {
                    if(response.success) {
                        var data = response.data;
                        var vendor = response.vendor;
                        var items = response.items;
                        var itemsHtml = "<ul>";
                        items.forEach(function(item) {
                            itemsHtml += "<li>Item: " + item.name + ", Quantity: " + item.qty + "</li>";
                        });
                        itemsHtml += "</ul>";

                        $("#purchase-order-details").html(
                            "<p><strong>Purchase Order Number:</strong> " + data.po_number + "</p>" +
                            "<p><strong>Reference:</strong> " + data.reference + "</p>" +
                            "<p><strong>PO Date:</strong> " + data.po_date + "</p>" +
                            "<p><strong>Delivery Date:</strong> " + data.delivery_date + "</p>" +
                            "<p><strong>Payment Terms:</strong> " + data.payment_terms + "</p>" +
                            "<p><strong>Vendor:</strong> " + vendor.name + "</p>" +
                            "<p><strong>Items:</strong> " + itemsHtml + "</p>"
                        );
                    } else {
                        $("#purchase-order-details").html("<p>" + response.message + "</p>");
                    }
                }
            });
        } else {
            $("#purchase-order-details").empty();
        }
    });
');
?>
