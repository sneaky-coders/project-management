<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use app\models\Vendor;
use app\models\Units;
use app\models\Items;

/* @var $this yii\web\View */
/* @var $model app\models\PurchaseOrder */
/* @var $form yii\widgets\ActiveForm */

$itemsList = Items::find()->all(); // Retrieve all items
$itemOptions = ArrayHelper::map($itemsList, 'id', 'item_name'); // Map items to dropdown options
$paymentTermsOptions = [
    'Net 30' => 'Net 30 Days',
    'Net 60' => 'Net 60 Days',
    'Net 90' => 'Net 90 Days',
    'Immediate' => 'Immediate Payment',
    // Add more options as needed
];

// Get the selected items for the current purchase order
$selectedItems = $model->getItems();
$selectedItemIds = ArrayHelper::getColumn($selectedItems, 'id');
$selectedItemNames = ArrayHelper::map($selectedItems, 'id', 'item_name');
?>

<div class="purchase-order-form container">

    <?php $form = ActiveForm::begin([
        'options' => ['class' => 'form-horizontal'],
    ]); ?>

    <div class="row">
        <div class="col-md-6">
            <?= $form->field($model, 'vendor_id')->dropDownList(
                ArrayHelper::map(Vendor::find()->all(), 'vendor_id', 'name'),
                ['prompt' => 'Select Vendor']
            ) ?>
        </div>
        <div class="col-md-6">
            <?= $form->field($model, 'po_number')->textInput(['maxlength' => true]) ?>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <?= $form->field($model, 'reference')->textInput(['maxlength' => true]) ?>
        </div>
        <div class="col-md-6">
            <?= $form->field($model, 'po_date')->textInput(['type' => 'date']) ?>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <?= $form->field($model, 'delivery_date')->textInput(['type' => 'date']) ?>
        </div>
        <div class="col-md-6">
            <?= $form->field($model, 'payment_terms')->dropDownList(
                $paymentTermsOptions,
                ['prompt' => 'Select Payment Terms']
            ) ?>
        </div>
    </div>

    <div class="form-group">
        <?= Html::label('Item', 'item_id', ['class' => 'control-label']) ?>
        <?= Html::dropDownList('PurchaseOrder[item_id][]', $selectedItemIds, $itemOptions, [
            'id' => 'item-dropdown',
            'multiple' => 'multiple',
            'class' => 'form-control',
            'prompt' => 'Select Items'
        ]) ?>

        <button type="button" id="add-item" class="btn btn-primary mt-2">+ Add Item</button>
    </div>

    <div id="selected-items" class="form-group">
        <label class="control-label">Selected Items</label>
        <ul id="items-list" class="list-unstyled">
            <?php foreach ($selectedItemNames as $itemId => $itemName): ?>
                <li data-value="<?= $itemId ?>">
                    <?= Html::encode($itemName) ?>
                    <span class="remove-item" style="cursor: pointer; color: red;">x</span>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>

    <div class="row">
        <div class="col-md-6">
            <?= $form->field($model, 'unit_id')->dropDownList(
                ArrayHelper::map(Units::find()->all(), 'id', 'name'),
                ['prompt' => 'Select Unit']
            ) ?>
        </div>
        <div class="col-md-6">
            <?= $form->field($model, 'qty')->textInput(['type' => 'number']) ?>
        </div>
    </div>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>

<!-- Include the JavaScript below for functionality -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const itemDropdown = document.getElementById('item-dropdown');
        const itemsList = document.getElementById('items-list');
        const itemIdsInput = document.createElement('input');
        itemIdsInput.type = 'hidden';
        itemIdsInput.name = 'PurchaseOrder[item_id]';
        document.querySelector('form').appendChild(itemIdsInput);

        function updateHiddenInput() {
            const remainingItems = Array.from(itemsList.children).map(li => li.dataset.value);
            itemIdsInput.value = JSON.stringify(remainingItems);
        }

        function addSelectedItems() {
            const selectedOptions = Array.from(itemDropdown.selectedOptions);
            selectedOptions.forEach(option => {
                if (option.value) {
                    const existingItems = Array.from(itemsList.children).map(li => li.dataset.value);
                    if (!existingItems.includes(option.value)) {
                        const li = document.createElement('li');
                        li.textContent = option.textContent;
                        li.dataset.value = option.value;
                        li.innerHTML += ' <span class="remove-item" style="cursor: pointer; color: red;">x</span>';
                        itemsList.appendChild(li);
                    }
                }
            });
            updateHiddenInput();
        }

        itemDropdown.addEventListener('change', function () {
            addSelectedItems();
        });

        itemsList.addEventListener('click', function (event) {
            if (event.target.classList.contains('remove-item')) {
                const li = event.target.parentElement;
                li.remove();
                updateHiddenInput();
            }
        });

        // Initialize the hidden input value on page load
        updateHiddenInput();
    });
</script>


<!-- Include styles -->
<style>
    .purchase-order-form {
        padding: 20px;
        background-color: #f8f9fa;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .form-horizontal .form-group {
        margin-bottom: 1.5rem;
    }

    .form-horizontal .control-label {
        font-weight: bold;
    }

    .btn-primary {
        background-color: #007bff;
        border-color: #007bff;
        color: #fff;
        font-weight: bold;
        transition: background-color 0.3s ease;
    }

    .btn-primary:hover {
        background-color: #0056b3;
        border-color: #0056b3;
    }

    #selected-items ul {
        margin: 0;
        padding: 0;
        list-style-type: none;
    }

    #selected-items li {
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 4px;
        margin-bottom: 5px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        background-color: #fff;
    }

    #selected-items li span.remove-item {
        margin-left: 10px;
        font-weight: bold;
    }

    .form-control {
        border-radius: 4px;
    }

    .container {
        max-width: 1200px;
        margin: auto;
    }
    .help-block
    {
        color:red;
    }
</style>
