<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Chartofaccounts */

$this->title = 'Create Chartofaccounts';
$this->params['breadcrumbs'][] = ['label' => 'Chartofaccounts', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="chartofaccounts-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
