<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\SearchChartofaccounts */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Chartofaccounts';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="chartofaccounts-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Create Chartofaccounts', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'account_id',
            'account_code',
            'account_name',
            'account_type',
            'parent_id',
            //'description:ntext',
            //'is_active',
            //'created_at',
            //'updated_at',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>


</div>
