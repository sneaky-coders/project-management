<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Chartofaccounts */
/* @var $accounts array */
/* @var $startDate string */
/* @var $endDate string */
/* @var $totalAmount float */
/* @var $chartData string */

$this->title = 'Chart of Accounts Report';
?>
<div class="chartofaccounts-report container-fluid">

    <h1><?= Html::encode($this->title) ?></h1>

    <?php $form = ActiveForm::begin(['method' => 'post']); ?>

    <div class="row">
        <div class="col-md-6">
            <?= $form->field($model, 'start_date')->input('date', ['value' => $startDate]) ?>
        </div>
        <div class="col-md-6">
            <?= $form->field($model, 'end_date')->input('date', ['value' => $endDate]) ?>
        </div>
    </div>

    <div class="form-group">
        <?= Html::submitButton('Generate Report', ['class' => 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="report-summary">
                <h2>Report Summary</h2>
                <p>Total Amount from Sales Order: <strong><?= Html::encode(number_format($totalAmount, 2)) ?></strong></p>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12 chart-section">
            <h2>Account Distribution</h2>
            <div class="chart-container">
                <canvas id="barChart"></canvas>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12 records-section">
            <h2>Account Details</h2>
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Account Code</th>
                        <th>Account Name</th>
                        <th>Account Type</th>
                        <th>Created At</th>
                        <th>Updated At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($accounts as $account): ?>
                        <tr>
                            <td><?= Html::encode($account['account_code']) ?></td>
                            <td><?= Html::encode($account['account_name']) ?></td>
                            <td><?= Html::encode($account['account_type']) ?></td>
                            <td><?= Html::encode($account['created_at']) ?></td>
                            <td><?= Html::encode($account['updated_at']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- Include Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Check if chartData is available
    console.log('Chart Data:', <?= $chartData ?>);

    var ctx = document.getElementById('barChart').getContext('2d');
    var chartData = <?= $chartData ?>;

    // Ensure chartData is an array of objects with label and value
    if (Array.isArray(chartData) && chartData.length > 0) {
        var labels = chartData.map(function(item) { return item.label; });
        var data = chartData.map(function(item) { return item.value; });

        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Account Distribution',
                    data: data,
                    backgroundColor: '#4BC0C0',
                    borderColor: '#36A2EB',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                if (context.parsed !== null) {
                                    label += context.parsed + ' units';
                                }
                                return label;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        beginAtZero: true
                    },
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    } else {
        console.warn('No chart data available.');
    }
});
</script>

<style>
    .chartofaccounts-report {
        padding: 20px;
        background-color: #f5f5f5;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .report-summary, .chart-section, .records-section {
        margin-bottom: 30px;
        padding: 20px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .chart-section {
        margin-top: 20px;
    }

    .chart-container {
        width: 100%;
        height: 400px;
    }

    .table {
        margin-top: 20px;
        width: 100%;
    }

    .table th, .table td {
        text-align: center;
    }

    .btn-primary {
        background-color: #007bff;
        border-color: #007bff;
    }

    .btn-primary:hover {
        background-color: #0056b3;
        border-color: #004085;
    }
</style>
