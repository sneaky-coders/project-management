<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Chartofaccounts */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="chartofaccounts-form custom-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'account_code')->textInput(['maxlength' => true, 'readonly' => true, 'class' => 'custom-input']) ?>

    <?= $form->field($model, 'account_name')->textInput(['maxlength' => true, 'class' => 'custom-input']) ?>

    <?= $form->field($model, 'account_type')->dropDownList([ 
        'Asset' => 'Asset', 
        'Liability' => 'Liability', 
        'Equity' => 'Equity', 
        'Revenue' => 'Revenue', 
        'Expense' => 'Expense', 
    ], ['prompt' => '', 'class' => 'custom-select']) ?>

    <?= $form->field($model, 'parent_id')->textInput(['class' => 'custom-input']) ?>

    <?= $form->field($model, 'description')->textarea(['rows' => 6, 'class' => 'custom-textarea']) ?>

    <?= $form->field($model, 'is_active')->checkbox(['class' => 'custom-checkbox']) ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'custom-button']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Function to generate a new account code
    function generateAccountCode() {
        // Fetch the last used number from a hidden field or API
        var lastNumber = parseInt(document.getElementById('last-account-number').value) || 0;
        
        // Increment the last number and format it with the "AnX" prefix
        var newNumber = ('0000' + (lastNumber + 1)).slice(-6);
        var accountCode = 'AnX' + newNumber;
        
        // Set the new account code in the input field
        document.getElementById('chartofaccounts-account_code').value = accountCode;
        
        // Update the last number value in the hidden field or backend
        document.getElementById('last-account-number').value = lastNumber + 1;
    }
    
    // Generate a new account code when the form loads
    generateAccountCode();
});
</script>

<!-- Hidden field to store the last used number -->
<input type="hidden" id="last-account-number" value="0">

<style>
    .custom-form {
        max-width: 800px;
        margin: auto;
        padding: 20px;
        background-color: #f9f9f9;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .custom-input,
    .custom-select,
    .custom-textarea {
        border-radius: 4px;
        border: 1px solid #ddd;
        padding: 8px 12px;
        margin-bottom: 15px;
        width: 100%;
    }

    .custom-checkbox {
        margin-top: 8px;
    }

    .custom-button {
        padding: 10px 20px;
        border-radius: 4px;
        border: none;
        background-color: #28a745;
        color: #fff;
        font-size: 16px;
        cursor: pointer;
    }

    .custom-button:hover {
        background-color: #218838;
    }

</style>
