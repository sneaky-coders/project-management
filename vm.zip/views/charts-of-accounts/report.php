<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $chartOfAccounts app\models\Chartofaccounts[] */
/* @var $invoices app\models\Invoice[] */

$this->title = 'Chart of Accounts Report';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="chartofaccounts-report">

    <h1><?= Html::encode($this->title) ?></h1>

    <h2>Chart of Accounts</h2>
    <?= GridView::widget([
        'dataProvider' => new \yii\data\ArrayDataProvider([
            'allModels' => $chartOfAccounts,
            'sort' => [
                'attributes' => ['account_code', 'account_name', 'account_type', 'description'],
            ],
            'pagination' => [
                'pageSize' => 10,
            ],
        ]),
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            'account_code',
            'account_name',
            'account_type',
            'description',
            // Other columns as needed
        ],
    ]); ?>

    <h2>Invoices</h2>
    <?= GridView::widget([
        'dataProvider' => new \yii\data\ArrayDataProvider([
            'allModels' => $invoices,
            'sort' => [
                'attributes' => ['invoice_number', 'invoice_date', 'total'],
            ],
            'pagination' => [
                'pageSize' => 10,
            ],
        ]),
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            'invoice_number',
            'invoice_date',
            'total',
            // Other columns as needed
        ],
    ]); ?>

</div>
