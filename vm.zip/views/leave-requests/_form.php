<?php

use app\models\Employee;
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\LeaveTypes;

/* @var $this yii\web\View */
/* @var $model app\models\LeaveRequests */
/* @var $employee app\models\Employee */
/* @var $form yii\widgets\ActiveForm */
$userId = Yii::$app->user->identity->user_id;
$employee = Employee::findOne(['user_id' => $userId]);
?>

<div class="leave-requests-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'employee_id')->textInput([
        'type' => 'number', // Ensure the input type is 'number'
        'value' => (int)$employee->id, // Convert to integer using typecast
        'readonly' => true,
    ]) ?>



    <?= $form->field($model, 'leave_type_id')->dropDownList(
        \yii\helpers\ArrayHelper::map(LeaveTypes::find()->all(), 'id', 'name'),
        ['prompt' => 'Select Leave Type']
    ) ?>

    <?= $form->field($model, 'start_date')->textInput(['type' => 'date']) ?>

    <?= $form->field($model, 'end_date')->textInput(['type' => 'date']) ?>

    <?= $form->field($model, 'status')->hiddenInput(['value' => 'pending'])->label(false) ?>

    <?= $form->field($model, 'reason')->textarea(['rows' => 6]) ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>