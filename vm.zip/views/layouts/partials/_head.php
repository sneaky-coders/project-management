<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>AnkyPro-Connect - ERP System</title>

<!-- All Library CSS -->

<link href="/css/bootstrap.min.css" rel="stylesheet" />
<link href="/css/LineIcons.css" rel="stylesheet">
<link href="/css/viewer.min.css" rel="stylesheet">
<link href="/css/icofont.min.css" rel="stylesheet">
<link href="/css/calendar.css" rel="stylesheet">
<!-- Custom CSS -->
<link href="/css/styles.css" rel="stylesheet">
<link href="/css/responsive.css" rel="stylesheet">
<!-- Favicon -->
<link rel="shortcut icon" href="/images/restro1.png">