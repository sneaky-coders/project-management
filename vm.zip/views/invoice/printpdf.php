<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */
/* @var $overall float */
/* @var $filter_option string */
/* @var $start_date string */
/* @var $end_date string */
/* @var $payment_status string */

$this->title = 'Sales Report';

// Register CSS for print styles
$this->registerCss('
    .invoice-report {
        font-family: Arial, sans-serif; /* Specify a suitable font for printing */
    }
    .filter-criteria, .total-amount {
        margin-bottom: 20px; /* Add space between sections */
    }
    .total-amount {
        background-color: #f0f0f0;
        padding: 10px;
        border: 1px solid #ccc;
    }
    .grid-view {
        margin-top: 20px; /* Add space above the GridView */
    }
    .print-button {
        display: block; /* Show the print button by default */
        text-align: center; /* Center-align the button text */
        margin: 20px auto 0; /* Add margin to top (20px), center horizontally (auto), and 0 margin at the bottom */
    }
    
    /* Media query to hide print button when printing */
    @media print {
        .print-button {
            display: none; /* Hide the print button when printing */
        }
    }
');

?>

<div class="invoice-report">

    <h1 class="header"><?= Html::encode($this->title) ?></h1>

    <!-- Filter Criteria -->
    <div class="filter-criteria">
        <?php if ($filter_option === 'date_status' && !empty($start_date) && !empty($end_date)): ?>
            <p><strong>Date Range:</strong> <?= Yii::$app->formatter->asDate($start_date) ?> to <?= Yii::$app->formatter->asDate($end_date) ?></p>
        <?php endif; ?>
        <?php if ($payment_status !== null): ?>
            <p><strong>Payment Status:</strong> <?= $payment_status === '1' ? 'Paid' : 'Not Paid' ?></p>
        <?php endif; ?>
    </div>

    <!-- Total Amount -->
    <div class="total-amount">
        <p><strong>Total Amount:</strong> INR <?= Yii::$app->formatter->asDecimal($overall) ?></p>
    </div>

    <!-- Invoice Table -->
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            'invoice_number',
            [
                'attribute' => 'invoice_date',
                'format' => ['date', 'php:d M Y'],
            ],
            [
                'attribute' => 'client.companyname',
                'label' => 'Client Name',
            ],
            [
                'attribute' => 'total',
                'format' => ['currency', 'INR'],
            ],
            [
                'attribute' => 'payment_status',
                'value' => function ($model) {
                    return $model->payment_status == 1 ? 'Paid' : 'Not Paid';
                },
            ],
        ],
    ]); ?>

    <!-- Print Button (Visible only when not printing) -->
    <div class="print-button">
        <?= Html::button('Print/Download Report', ['class' => 'btn btn-primary', 'onclick' => 'window.print();']) ?>
    </div>

</div>
