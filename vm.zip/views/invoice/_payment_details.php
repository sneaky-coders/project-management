<?php
/* @var $payments app\models\Payment[] */
?>

<?php if (!empty($payments)): ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Amount</th>
                <th>Date</th>
                <th>Method</th>
                <th>Description</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($payments as $payment): ?>
                <tr>
                    <td><?= Yii::$app->formatter->asCurrency($payment->amount) ?></td>
                    <td><?= Yii::$app->formatter->asDate($payment->payment_date) ?></td>
                    <td><?= Html::encode($payment->payment_method) ?></td>
                    <td><?= Html::encode($payment->description) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php else: ?>
    <p>No payment details available for this invoice.</p>
<?php endif; ?>
