<?php
use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ActiveForm;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $searchModel app\models\SearchInvoice */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Sales Orders';
$this->params['breadcrumbs'][] = $this->title;
?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

<div class="invoice-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <div class="row mb-3">
        <div class="col-md-6">
            <?php $form = ActiveForm::begin([
                'action' => ['index'], // Action for submitting the search form
                'method' => 'get',
                'options' => ['class' => 'form-inline'],
            ]); ?>
            <div class="input-group">
                <?= $form->field($searchModel, 'invoice_number')->textInput(['placeholder' => 'Search by invoice number', 'class' => 'form-control'])->label(false) ?>
                <div class="input-group-append">
                    <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
                </div>
            </div>
            <?php ActiveForm::end(); ?>
        </div>
        <div class="col-md-6 text-right">
            <?= Html::a('<i class="bi bi-plus"></i> New Invoice', ['create'], ['class' => 'btn btn-success']) ?>
        </div>
    </div>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'tableOptions' => ['class' => 'table table-striped table-bordered'],
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            'invoice_number',
            'invoice_date:date',
            [
                'attribute' => 'client_name',
                'value' => 'client.companyname'
            ],
            'total',
            'currency',
            [
                'attribute' => 'payment_status',
                'value' => function ($model) {
                    return $model->payment_status == 1 ? 'Paid' : 'Not Paid';
                },
                'filter' => ['1' => 'Paid', '0' => 'Not Paid'],
                'contentOptions' => ['class' => 'text-center'],
            ],
            [
                'class' => 'yii\grid\ActionColumn',
                'template' => '{view} {update} {delete} {payment-details} {mark-as-paid} {fetch-payment-details}',
                'contentOptions' => ['class' => 'text-center'],
               'buttons' => [
    'view' => function ($url, $model) {
        return Html::a('<span class="bi bi-eye"></span>', ['view', 'id' => $model->invoice_id], ['class' => 'btn btn-info btn-sm', 'title' => 'View']);
    },
    'update' => function ($url, $model) {
        return Html::a('<span class="bi bi-pencil"></span>', ['update', 'id' => $model->invoice_id], ['class' => 'btn btn-primary btn-sm', 'title' => 'Update']);
    },
    'delete' => function ($url, $model) {
        return Html::a('<span class="bi bi-trash"></span>', ['delete', 'id' => $model->invoice_id], [
            'class' => 'btn btn-danger btn-sm',
            'title' => 'Delete',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]);
    },
    'payment-details' => function ($url, $model) {
        if ($model->payment_status == 1) {
            // Check if payment details are submitted
            $paymentSubmitted = \app\models\Payment::find()->where(['invoice_id' => $model->invoice_id])->exists();
            $btnClass = $paymentSubmitted ? 'btn-success' : 'btn-warning';
            $btnTitle = $paymentSubmitted ? 'Payment Details Submitted' : 'Submit Payment Details';
            return Html::a('<span class="bi bi-credit-card"></span>', '#', [
                'class' => "btn $btnClass btn-sm payment-details-btn",
                'title' => $btnTitle,
                'data-id' => $model->invoice_id,
                'data-toggle' => 'modal',
                'data-target' => '#paymentDetailsModal',
            ]);
        }
        return ''; // Return empty string if the invoice is not paid
    },
    'mark-as-paid' => function ($url, $model) {
        if ($model->payment_status == 0) {
            return Html::a('<span class="bi bi-check-circle"></span>', '#', [
                'class' => 'btn btn-success btn-sm mark-as-paid-btn',
                'title' => 'Mark as Paid',
                'data-id' => $model->invoice_id,
                'data-confirm' => 'Are you sure you want to mark this invoice as paid?',
            ]);
        }
        return ''; // Return empty string if the invoice is already paid
    },
    'fetch-payment-details' => function ($url, $model) {
        // Check if payment details already exist
        $paymentExists = \app\models\Payment::find()->where(['invoice_id' => $model->invoice_id])->exists();
        if ($paymentExists) {
            return Html::a('<span class="bi bi-info-circle"></span>', '#', [
                'class' => 'btn btn-info btn-sm fetch-payment-details-btn',
                'title' => 'Fetch Payment Details',
                'data-id' => $model->invoice_id,
                'data-toggle' => 'modal',
                'data-target' => '#fetchPaymentDetailsModal',
            ]);
        }
        return ''; // Return empty string if payment details do not exist
    },
],

            ],
        ],
    ]); ?>

</div>

<!-- Payment Details Modal -->
<div class="modal fade" id="paymentDetailsModal" tabindex="-1" role="dialog" aria-labelledby="paymentDetailsModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="paymentDetailsModalLabel">Payment Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Payment details form -->
                <form id="paymentDetailsForm" action="<?= Url::to(['invoice/process-payment']) ?>" method="post">
                    <div class="form-group">
                        <label for="invoice_number">Invoice Number</label>
                        <input type="text" class="form-control" id="invoice_number" name="invoice_number" readonly>
                    </div>
                    <div class="form-group">
                        <label for="payment_amount">Amount</label>
                        <input type="text" class="form-control" id="payment_amount" name="payment_amount" readonly>
                    </div>
                    <div class="form-group">
                        <label for="payment_date">Date</label>
                        <input type="date" class="form-control" id="payment_date" name="payment_date" required>
                    </div>
                    <div class="form-group">
                        <label for="payment_method">Payment Method</label>
                        <select class="form-control" id="payment_method" name="payment_method" required>
                            <option value="Credit Card">Credit Card</option>
                            <option value="Bank Transfer">Bank Transfer</option>
                            <option value="Cash">Cash</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="payment_description">Description</label>
                        <textarea class="form-control" id="payment_description" name="payment_description"></textarea>
                    </div>
                    <input type="hidden" id="invoice_id" name="invoice_id">
                    <button type="submit" class="btn btn-primary">Submit Payment</button>
                </form>
                <div id="paymentStatusMessage"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Fetch Payment Details Modal -->
<div class="modal fade" id="fetchPaymentDetailsModal" tabindex="-1" role="dialog" aria-labelledby="fetchPaymentDetailsModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="fetchPaymentDetailsModalLabel">Payment Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="fetchPaymentDetailsContent">
                <!-- Payment details will be loaded here via AJAX -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Include Bootstrap and jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
$(document).ready(function() {
    // Handle fetch payment details button click
    $('.fetch-payment-details-btn').on('click', function() {
        var invoiceId = $(this).data('id');
        $.ajax({
            url: '<?= Url::to(['invoice/fetch-payment-details']) ?>',
            type: 'GET',
            data: { id: invoiceId },
            dataType: 'json',
            success: function(data) {
                if (data.success) {
                    var details = data.details;
                    var content = '<p><strong>Invoice Number:</strong> ' + details.invoice_number + '</p>' +
                                  '<p><strong>Amount:</strong> ' + details.amount + '</p>' +
                                  '<p><strong>Date:</strong> ' + details.payment_date + '</p>' +
                                  '<p><strong>Method:</strong> ' + details.payment_method + '</p>' +
                                  '<p><strong>Description:</strong> ' + details.description + '</p>';
                    $('#fetchPaymentDetailsContent').html(content);
                    $('#fetchPaymentDetailsModal').modal('show');
                } else {
                    $('#fetchPaymentDetailsContent').html('<p>' + data.message + '</p>');
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', status, error);
                $('#fetchPaymentDetailsContent').html('<p>Error fetching payment details.</p>');
            }
        });
    });

    // Handle payment details button click
    $('.payment-details-btn').on('click', function() {
        var invoiceId = $(this).data('id');
        $.ajax({
            url: '<?= Url::to(['invoice/payment-details']) ?>',
            type: 'GET',
            data: { id: invoiceId },
            dataType: 'json',
            success: function(data) {
                if (data.invoice_id) {
                    $('#invoice_id').val(data.invoice_id);
                    $('#invoice_number').val(data.invoice_number);
                    $('#payment_amount').val(data.total);
                } else {
                    $('#paymentDetailsModal .modal-body').html('<p>Invoice details not found.</p>');
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', status, error);
                $('#paymentDetailsModal .modal-body').html('<p>Error loading payment details.</p>');
            }
        });
    });

    // Handle payment processing form submission
    $('#paymentDetailsForm').on('submit', function(e) {
        e.preventDefault();
        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    $('#paymentDetailsModal').modal('hide');
                    location.reload(); // Reload the page to see the changes
                } else {
                    $('#paymentStatusMessage').html('<div class="alert alert-danger">Payment processing failed.</div>');
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', status, error);
                $('#paymentStatusMessage').html('<div class="alert alert-danger">An error occurred while processing the payment.</div>');
            }
        });
    });

    // Handle mark as paid button click
    $(document).on('click', '.mark-as-paid-btn', function(e) {
        e.preventDefault();
        var invoiceId = $(this).data('id');
        if (confirm('Are you sure you want to mark this invoice as paid?')) {
            $.ajax({
                url: '<?= Url::to(['invoice/mark-as-paid']) ?>',
                type: 'POST',
                data: { id: invoiceId },
                dataType: 'json',
                headers: {
                    'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    if (response.success) {
                        location.reload(); // Reload the page to see the changes
                    } else {
                        alert('Failed to update payment status.');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', status, error);
                    alert('An error occurred while updating payment status.');
                }
            });
        }
    });

    // Ensure modals are hidden properly
    $('#fetchPaymentDetailsModal').on('hidden.bs.modal', function() {
        $('#fetchPaymentDetailsContent').html('');
    });

    $('#paymentDetailsModal').on('hidden.bs.modal', function() {
        $('#paymentDetailsForm')[0].reset();
        $('#paymentStatusMessage').html('');
    });

    // Reinitialize Bootstrap tooltips and popovers if used
    $('[data-toggle="tooltip"]').tooltip();
    $('[data-toggle="popover"]').popover();
});


</script>
