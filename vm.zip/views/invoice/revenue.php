<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ActiveForm;
use yii\helpers\Json;
use app\models\Invoice;
use app\models\Purchase;

$this->title = 'Overview';
$this->params['breadcrumbs'][] = $this->title;

// Fetch data from database
$invoiceData = Invoice::find()
    ->select(['MONTH(invoice_date) AS month', 'SUM(total) AS total'])
    ->groupBy('MONTH(invoice_date)')
    ->orderBy('MONTH(invoice_date)')
    ->asArray()
    ->all();

$purchaseData = Purchase::find()
    ->select(['MONTH(created_at) AS month', 'SUM(amount) AS amount'])
    ->groupBy('MONTH(created_at)')
    ->orderBy('MONTH(created_at)')
    ->asArray()
    ->all();

// Prepare data for the chart
$labels = [];
$invoiceRevenueData = [];
$purchaseRevenueData = [];

foreach ($invoiceData as $item) {
    $labels[] = Yii::$app->formatter->asDate($item['month'], 'php:M'); // Format month name
    $invoiceRevenueData[] = (int) $item['total'];
}

foreach ($purchaseData as $item) {
    $purchaseRevenueData[] = (int) $item['amount'];
}

// Encode data to be used in JavaScript
$chartDataJson = Json::encode([
    'labels' => $labels,
    'invoiceData' => $invoiceRevenueData,
    'purchaseData' => $purchaseRevenueData,
]);


// Registering JavaScript code to render the chart using Chart.js library
$js = <<< JS
var ctx = document.getElementById('revenue-chart').getContext('2d');
var chartData = $chartDataJson;

var myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: chartData.labels,
        datasets: [
            {
                label: 'Sales Order Revenue',
                data: chartData.invoiceData,
                fill: false,
                borderColor: 'rgb(54, 162, 235)',
                tension: 0.1
            },
            {
                label: 'Purchase',
                data: chartData.purchaseData,
                fill: false,
                borderColor: 'rgb(255, 99, 132)',
                tension: 0.1
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        aspectRatio: 1.5, // Adjust the aspect ratio as needed
        plugins: {
            legend: {
                position: 'top',
            },
            tooltip: {
                mode: 'index',
                intersect: false,
            }
        },
        scales: {
            x: {
                display: true,
                title: {
                    display: true,
                    text: 'Month'
                }
            },
            y: {
                display: true,
                title: {
                    display: true,
                    text: 'Revenue (INR)'
                }
            }
        }
    }
});
JS;
$this->registerJs($js);
?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<div class="reports-index">
    <h1><?= Html::encode($this->title) ?></h1>

    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h3 class="card-title"><i class="fas fa-calendar icon"></i> Filter Options</h3>
                </div>
                <div class="card-body">
                    <?php $form = ActiveForm::begin([
                        'method' => 'get',
                        'action' => ['invoice/revenue'],
                        'options' => ['class' => 'form-horizontal'],
                    ]); ?>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <?= $form->field($invoiceSearchModel, 'start_date')->textInput(['type' => 'date', 'class' => 'form-control'])->label('Start Date') ?>
                        </div>
                        <div class="form-group col-md-6">
                            <?= $form->field($invoiceSearchModel, 'end_date')->textInput(['type' => 'date', 'class' => 'form-control'])->label('End Date') ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <?= Html::submitButton('<i class="fas fa-chart-bar"></i> Generate Report', ['class' => 'btn btn-primary']) ?>
                    </div>

                    <?php ActiveForm::end(); ?>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h3 class="card-title"><i class="fas fa-file-text icon"></i> Total Revenue</h3>
                </div>
                <div class="card-body">
                    <p class="card-text">Date Range: <?= Yii::$app->formatter->asDate($startDate) ?> to <?= Yii::$app->formatter->asDate($endDate) ?></p>

                    <div class="row">
                        <div class="col-md-6">
                            <p class="card-text">Total Sales Revenue:</p>
                            <h4 class="card-title"><?= Yii::$app->formatter->asCurrency($invoiceDataProvider->query->sum('total'), 'INR') ?></h4>
                        </div>
                        <div class="col-md-6">
                            <p class="card-text">Total Purchase:</p>
                            <h4 class="card-title"><?= Yii::$app->formatter->asCurrency($purchaseDataProvider->query->sum('amount'), 'INR') ?></h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"><i class="fas fa-chart-line"></i> Revenue Overview</h3>
                </div>
                <div class="card-body">
                    <canvas id="revenue-chart" height="200"></canvas> <!-- Adjusted height here -->
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"><i class="fas fa-file-invoice icon"></i> Sales Order</h3>
                </div>
                <div class="card-body">
                    <?= GridView::widget([
                        'dataProvider' => $invoiceDataProvider,
                        'columns' => [
                            ['class' => 'yii\grid\SerialColumn'],

                            'invoice_number:text:Invoice Number',
                            [
                                'attribute' => 'invoice_date',
                                'label' => 'Invoice Date',
                                'format' => ['date', 'php:d-M-Y'],
                            ],
                            [
                                'attribute' => 'total',
                                'label' => 'Total Amount',
                                'format' => ['currency', 'INR'],
                            ],
                            // Other columns specific to invoices
                        ],
                    ]); ?>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"><i class="fas fa-shopping-cart icon"></i> Purchases</h3>
                </div>
                <div class="card-body">
                    <?= GridView::widget([
                        'dataProvider' => $purchaseDataProvider,
                        'columns' => [
                            ['class' => 'yii\grid\SerialColumn'],

                            'item:text:Item',
                            [
                                'attribute' => 'created_at',
                                'label' => 'Purchase Date',
                                'format' => ['date', 'php:d-M-Y'],
                            ],
                            [
                                'attribute' => 'amount',
                                'label' => 'Amount',
                                'format' => ['currency', 'INR'],
                            ],
                            // Other columns specific to purchases
                        ],
                    ]); ?>
                </div>
            </div>
        </div>
    </div>

</div>
