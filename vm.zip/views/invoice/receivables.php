<?php
use yii\helpers\Html;
use app\models\Invoice;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */
/* @var $totalAmount float */

$this->title = 'Receivables';
$this->params['breadcrumbs'][] = $this->title;

function formatCurrency($amount, $currencyCode = '₹') {
    return   $currencyCode.' '. number_format($amount, 2, '.', ',') ;
}

$paymentSum = Invoice::find()
    ->where(['payment_status' => 0])
    ->sum('total');
$unpaidInvoices = Invoice::find()->where(['payment_status' => 0])->all();
$totalAmount = array_sum(array_map(function($invoice) {
    return $invoice->total;
}, $unpaidInvoices));
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

<div class="receivables">

    <h1 class="page-header"><?= Html::encode($this->title) ?></h1>

    <div class="mb-4">
        <h3>Total Unpaid Amount: <?= formatCurrency($totalAmount) ?></h3>
    </div>

    <?= Html::beginForm(['invoice/receivables'], 'get', ['class' => 'form-inline']) ?>
    <div class="form-group">
        <?= Html::submitButton('Refresh', ['class' => 'btn btn-primary']) ?>
    </div>
    <?= Html::endForm() ?>

    <table class="table table-striped table-bordered table-hover mt-4">
        <thead>
            <tr>
                <th>#</th> <!-- Serial Number Column -->
                <th>Client</th>
                <th>Invoice Number</th>
                <th>Invoice Date</th>
                <th>Account</th>
                <th>Total Amount</th>
                <th>Balance Due</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $serialNumber = 1; // Initialize serial number ?>
            <?php foreach ($dataProvider->getModels() as $invoice): ?>
            <tr>
                <td><?= $serialNumber++ ?></td> <!-- Display Serial Number -->
                <td><?= Html::encode($invoice->client->companyname) ?></td>
                <td><?= Html::encode($invoice->invoice_number) ?></td>
                <td><?= Yii::$app->formatter->asDate($invoice->invoice_date, 'php:Y-m-d') ?></td>
                <td><?= Html::encode($invoice->account->account_name) ?></td>
                <td><?= formatCurrency($invoice->total) ?></td>
                <td><?= formatCurrency($invoice->total - $paymentSum) ?></td>
                <td>
                    <?= Html::button('<i class="fas fa-list"></i>', [
                        'class' => 'btn btn-info btn-sm',
                        'data-toggle' => 'modal',
                        'data-target' => '#invoiceModal-' . $invoice->invoice_id,
                        'title' => 'View Items',
                    ]) ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <!-- Modals -->
    <?php foreach ($dataProvider->getModels() as $invoice): ?>
    <div class="modal fade" id="invoiceModal-<?= $invoice->invoice_id ?>" tabindex="-1" role="dialog" aria-labelledby="invoiceModalLabel-<?= $invoice->invoice_id ?>" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="invoiceModalLabel-<?= $invoice->invoice_id ?>">Invoice #<?= Html::encode($invoice->invoice_number) ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Invoice Details -->
                    <p><strong>Client:</strong> <?= Html::encode($invoice->client->companyname) ?></p>
                    <p><strong>Invoice Date:</strong> <?= Yii::$app->formatter->asDate($invoice->invoice_date, 'php:Y-m-d') ?></p>
                    <p><strong>Account:</strong> <?= Html::encode($invoice->account->account_name) ?></p>
                    <p><strong>Total Amount:</strong> <?= formatCurrency($invoice->total) ?></p>
                    <p><strong>Balance Due:</strong> <?= formatCurrency($invoice->total - $paymentSum) ?></p>

                    <!-- Items Table -->
                    <?php
                    $content = json_decode($invoice->content, true);
                    $sr_no = 1;
                    $subtotal = 0;

                    if (is_array($content)): ?>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Description</th>
                                    <th>Unit Price</th>
                                    <th>Quantity</th>
                                    <th>Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($content as $value): ?>
                                    <?php
                                    if (is_numeric($value[2]) && is_numeric($value[3])) {
                                        $lineSubtotal = $value[2] * $value[3];
                                        $subtotal += $lineSubtotal;
                                    } else {
                                        $lineSubtotal = 0;
                                    }
                                    ?>
                                    <tr>
                                        <td><?= $sr_no ?></td>
                                        <td>
                                            <p><?= Html::encode($value[0]) ?> <br><i><?= Html::encode($value[1]) ?></i></p>
                                        </td>
                                        <td><?= Html::encode($value[2]) ?></td>
                                        <td><?= Html::encode($value[3]) ?></td>
                                        <td><?= formatCurrency($lineSubtotal) ?></td>
                                    </tr>
                                    <?php $sr_no++; ?>
                                <?php endforeach; ?>
                                <tr>
                                    <td colspan="4" class="text-right"><strong>Subtotal:</strong></td>
                                    <td><?= formatCurrency($subtotal) ?></td>
                                </tr>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>

</div>

<style>
.page-header {
    font-size: 24px;
    font-weight: bold;
    color: #333;
    border-bottom: 2px solid #007bff;
    padding-bottom: 10px;
    margin-bottom: 20px;
}

.table {
    border-radius: 5px;
    overflow: hidden;
}

.table thead th {
    background-color: #f4f4f4;
    color: #333;
}

.table tbody tr:nth-child(odd) {
    background-color: #f9f9f9;
}

.table tbody tr:hover {
    background-color: #f1f1f1;
}

.btn-info {
    background-color: #17a2b8;
    border-color: #17a2b8;
}

.btn-info:hover {
    background-color: #138496;
    border-color: #117a8b;
}

.fas {
    font-family: 'Font Awesome 5 Free'; /* Use Font Awesome 5 */
    font-weight: 900;
}
</style>

<?php
$js = <<<JS
$(document).ready(function(){
    // Ensure all modals are initialized
    $('.modal').modal();
});
JS;
$this->registerJs($js);
?>
