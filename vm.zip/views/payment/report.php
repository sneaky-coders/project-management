<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use app\models\Payment;
use app\models\Invoice;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */
/* @var $paymentMethod string */

$this->title = 'Payments ';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="payment-report">

    <h1 class="page-header"><?= Html::encode($this->title) ?></h1>

    <div class="filter-container">
        <?php $form = ActiveForm::begin([
            'method' => 'get',
            'action' => ['report'],
            'options' => ['class' => 'filter-form'],
        ]); ?>
        <div class="form-group">
            <?= Html::dropDownList('payment_method', $paymentMethod, 
                ArrayHelper::map(Payment::find()->select('payment_method')->distinct()->all(), 'payment_method', 'payment_method'),
                ['prompt' => 'Select Payment Method', 'class' => 'form-control custom-dropdown']
            ) ?>
            <?= Html::submitButton('Filter', ['class' => 'btn btn-primary']) ?>
        </div>
        <?php ActiveForm::end(); ?>
    </div>

    <div class="table-container">
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Invoice Number</th>
                    <th>Invoice Date</th>
                    <th>Total Amount</th>
                    <th>Account</th>
                    <th>Payment Method</th>
                </tr>
            </thead>
            <tbody>
                <?php $totalAmount = 0; ?>
                <?php foreach ($dataProvider->getModels() as $index => $model): ?>
                    <tr>
                        <td><?= $index + 1 ?></td>
                        <td><?= Html::encode($model->invoice->invoice_number) ?></td>
                        <td><?= Yii::$app->formatter->asDate($model->invoice->invoice_date, 'php:Y-m-d') ?></td>
                        <td><?= is_numeric($model->invoice->total) ? Yii::$app->formatter->asDecimal($model->invoice->total, 2) : 'N/A' ?></td>
                        <td><?= Html::encode($model->invoice->account->account_name) ?></td>
                        <td><?= Html::encode($model->payment_method) ?></td>
                    </tr>
                    <?php $totalAmount += $model->invoice->total; ?>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="total-amount">
            Overall Total: <?= Yii::$app->formatter->asDecimal($totalAmount, 2) ?>
        </div>
    </div>

</div>

<style>
.page-header {
    font-size: 30px;
    font-weight: 700;
    color: #333;
    border-bottom: 3px solid #007bff;
    padding-bottom: 15px;
    margin-bottom: 30px;
    text-align: center;
}

.filter-container {
    display: flex;
    justify-content: center;
    margin-bottom: 30px;
}

.filter-form {
    display: flex;
    align-items: center;
}

.form-group {
    display: flex;
    align-items: center;
}

.custom-dropdown {
    border-radius: 8px;
    border: 1px solid #ccc;
    padding: 12px;
    font-size: 16px;
    width: 250px;
    margin-right: 10px;
    transition: border-color 0.3s ease;
}

.custom-dropdown:focus {
    border-color: #007bff;
    outline: none;
}

.btn-primary {
    background-color: #007bff;
    border-color: #007bff;
    border-radius: 8px;
    padding: 10px 20px;
    font-size: 16px;
    transition: background-color 0.3s ease;
}

.btn-primary:hover {
    background-color: #0056b3;
    border-color: #004085;
}

.table-container {
    max-width: 100%;
    overflow-x: auto;
}

.table {
    width: 100%;
    border-collapse: collapse;
    border-radius: 8px;
    overflow: hidden;
    background-color: #fff;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.table thead th {
    background-color: #007bff;
    color: #fff;
    font-weight: 600;
    padding: 12px;
    text-align: left;
}

.table tbody tr {
    transition: background-color 0.3s ease;
}

.table tbody tr:nth-child(odd) {
    background-color: #f9f9f9;
}

.table tbody tr:hover {
    background-color: #f1f1f1;
}

.table td {
    padding: 12px;
    border-bottom: 1px solid #ddd;
}

.total-amount {
    font-size: 18px;
    font-weight: 600;
    color: #333;
    text-align: right;
    margin-top: 20px;
}
</style>
