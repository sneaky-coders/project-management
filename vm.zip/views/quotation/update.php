<?php

use app\models\Client;
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\date\DatePicker;
use yii\helpers\ArrayHelper;
use kartik\select2\Select2;
use yii\widgets\Pjax;

/* @var $this yii\web\View */
/* @var $model app\models\Invoice */
/* @var $form yii\widgets\ActiveForm */
$this->title = "Update Quotation - " . $model->quotation_number;

?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
<style>
    body {
        font-weight: 400;
    }

    .quotation-form {
        padding: 20px;
        background-color: #f8f9fa;
        border: 1px solid #dee2e6;
        border-radius: 5px;
    }

    .form-control:focus {
        box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
    }

    .panel-heading {
        cursor: pointer;
    }
</style>

<div class="invoice-form">
    <?php $form = ActiveForm::begin(['action' => ['quotation/update-quotation']]); ?>
    <?= $form->field($model, 'quotation_id')->hiddenInput(['maxlength' => true])->label(false); ?>
    <div class="row">
        <div class="col-md-3">
            <?php Pjax::begin(['id' => 'countries']) ?>
            <?php
            $clients = Client::find()
                ->all();
            $client_array = ArrayHelper::map($clients, 'client_id', 'companyname');

            echo $form->field($model, 'client_id')->dropDownList($client_array, ['prompt' => 'Select client'])->label(false) ?>

            <?php Pjax::end() ?>


        </div>
        <div class="col-md-2">
            <?= $form->field($model, 'quotation_number')->textInput(['maxlength' => true, 'placeholder' => 'Auto-generated if empty'])->label(false) ?>
        </div>
        <div class="col-md-3">
           <?= $form->field($model, 'quotation_date')->textInput(['class' => 'form-control', 'type' => 'date', 'placeholder' => 'Select issue date ...'])->label(false) ?>
        </div>
        <div class="col-md-3">
           <?= $form->field($model, 'expiry_date')->textInput(['class' => 'form-control', 'type' => 'date', 'placeholder' => 'Select issue date ...'])->label(false) ?>
        </div>
     
        <div class="col-md-2">
            <?= $form->field($model, 'currency')->dropdownList(['INR' => "Indian Rupees", 'US Dollar' => "US Dollar"])->label(false) ?>
        </div>
    </div>

    <br>
    <table class="table table-bordered content-table">

        <thead class="thead-light">
            <tr>
                <th>#</th>
                <th>Item</th>
                <th>UNIT PRICE</th>
                <th>QTY</th>
                <th>TOTAL</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <tr class="tr-form">
                <td>#</td>
                <td>
                    <input type="text" class="item-input form-control" placeholder="Item sold"><br>
                    <input type="text" class="description-input form-control" placeholder="Description">
                </td>
                <td><input type="text" class="cost-input form-control" value="0"></td>
                <td><input type="text" class="qty-input form-control" value="0"></td>
                <td></td>
                <td>
                    <a style="padding: 3px 6px;" class="add-item-btn btn btn-default"><i class="bi bi-plus-lg"></i</a>
                </td>
            </tr>
            <?php
            $subtotal = 0;
            $itemtotal = 0;
            $model->content = json_decode($model->content);
            $discount_amount = 0;
            $gst_amount = 0;
            if (is_array($model->content)) {
                foreach ($model->content as $key => $value) {
                    if (is_numeric($value[2]) && is_numeric($value[3])) {
                        $subtotal += $value[2] * $value[3];
                    }
            ?>
                        <tr class='select-row'>
                            <td>#</td>
                            <td>
                                <p><?= $value[0] ?> <br><i><?= $value[1] ?></i></p>
                            </td>
                            <td><?= $value[2] ?></td>
                            <td><?= $value[3] ?></td>
                            <td class="amount"><?= is_numeric($value[2]) && is_numeric($value[3]) ? $value[2] * $value[3] : 0 ?></td>
                            <td>
                                <a style="padding: 3px 6px;" class="del-btn  btn btn-default"><i class="bi bi-trash"></i></a>
                                <a style="padding: 3px 6px; display: none;" class="up-btn btn btn-default"><span class="glyphicon glyphicon-menu-up"></span></a>
                                <a style="padding: 3px 6px; display: none;" class="down-btn btn btn-default"><span class="glyphicon glyphicon-menu-down"></span></a>
                                <input value="<?= $value[3] ?>" name="Quotation[qty][]">
                                <input type="hidden" value="<?= $value[0] ?>" name="Quotation[item][]">
                                <input type="hidden" value="<?= $value[1] ?>" name="Quotation[description][]">
                                <input type="hidden" value="<?= $value[2] ?>" name="Quotation[price][]">
                            </td>
                        </tr>
            <?php
                }
            }
            $itemtotal = $subtotal;
            ?>
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td><?= $form->field($model, 'discount')->textInput(['placeholder' => 'Discount %'])->label("Discount %") ?></td>
                <td class="discount-value">
                    <?php
                    if ($model->discount != "" &&  $model->discount != 0) {
                        echo $discount_amount = $subtotal * ($model->discount / 100);
                    } else {
                        echo 0;
                    }
                    ?>
                </td>
                <td>
                </td>
            </tr>
            <tr>
                <td colspan=3></td>
                <td><b>Subtotal</b></td>
                <td class="subtotal"><?= $subtotal - $discount_amount ?></td>
                <td>
                </td>
            </tr>
            <tr>
                <td colspan=3></td>
                <td><?= $form->field($model, 'gst')->textInput(['placeholder' => 'GST %'])->label("GST %") ?></td>
                <td class="gst-value">
                    <?php
                    if ($model->gst != "" &&  $model->gst != 0) {
                        echo $gst_amount = $subtotal * ($model->gst / 100);
                    } else {
                        echo 0;
                    }
                    ?>
                </td>
                <td>
                </td>
            </tr>
            <tr>

                <td colspan=3></td>
                <td><b>TOTAL</b></td>
                <td class="total">
                    <?php
                    echo ($subtotal - $discount_amount) + $gst_amount;
                    ?>
                </td>
                <td></td>
            </tr>
        </tbody>
    </table>


    <div class="panel settings panel-default">
        <div class="panel-heading">
            <h3 class="panel-title"><b>Additional Fields</b></h3>
        </div>
        <div class="panel-body">
            <div class="row">
                <div class="col-md-6">
                    <p><i>Any additional fields to be added in the invoice can be added using the following fields</i></p>
                </div>
                <div class="col-md-6 text-right">
                    <a class="field-btn btn btn-default">Add Field</a>
                </div>
            </div>
            <div class="fields">
                <?php if ($model->additional_fields != "") {
                    $extraFields = json_decode($model->additional_fields);
                    if (is_array($extraFields)) {
                        foreach ($extraFields as $key => $value) {
                ?>
                            <div class="row field-template">
                                <div class="col-md-3">
                                    <p>Field Label
                                        <input type="text" value="<?= $value[0] ?>" name="Quotation[field_label][]" class="form-control">
                                    </p>
                                </div>
                                <div class="col-md-3">
                                    <p>Field Value
                                        <input type="text" value="<?=  $value[1] ?>" name="Quotation[field_value][]" class="form-control">
                                    </p>
                                </div>
                                <div class="col-md-1 field-remove">
                                    <p><br>
                                        <a style="color: red;" class="btn btn-default"><span class="glyphicon glyphicon-remove"></span></a>
                                    </p>
                                </div>
                            </div>
                <?php
                        }
                    }
                }

                ?>
            </div>
        </div>
    </div>

    <div class="panel settings panel-default">
        <div class="panel-heading">
            <h3 class="panel-title"><b>Print Settings</b></h3>
        </div>
        <?php $setting = json_decode($model->quotation_option); ?>
        <div class="panel-body">
            <div class="row">
                <div class="col-md-2">

                    <div class="checkbox">
                        <label>
                            <input type="checkbox" name="Quotation[print_setting][]" value="hide_qty" <?= in_array("hide_qty", $setting) ? "checked" : "" ?>>
                            Hide Qty column
                        </label>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" name="Quotation[print_setting][]" value="hide_unit_price" <?= in_array("hide_unit_price", $setting) ? "checked" : "" ?>>
                            Hide unit price column
                        </label>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" name="Quotation[print_setting][]" value="hide_authorized_signature" <?= in_array("hide_authorized_signature", $setting) ? "checked" : "" ?>>
                            Hide authorized signature
                        </label>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" name="Quotation[print_setting][]" value="hide_logo" <?= in_array("hide_logo", $setting) ? "checked" : "" ?>>
                            Hide Logo
                        </label>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" name="Quotation[print_setting][]" value="hide_company_name" <?= in_array("hide_company_name", $setting) ? "checked" : "" ?>>
                            Hide company name
                        </label>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>


</div>
<input type="hidden" name="Quotation[quotation_number]">
<?php 
    $script = <<< JS
        $(document).ready(function(){
            let total = 0;
            let item_amount = $itemtotal;
            let discount_amount = $discount_amount;
            let gst_amount = $gst_amount;
            let selected_ele;
            $(".add-item-btn").click(function(){
                var item = $(".item-input").val();
                var description = $(".description-input").val();
                var cost = $(".cost-input").val();
                var qty = $(".qty-input").val();
                amount = 0;
                if(!isNaN(cost) && !isNaN(qty)){
                    amount = parseFloat((Number(cost) * parseFloat(qty))).toFixed(2);
                }else{
                    amount = 0;
                }
                var tr = '\
                <tr class=\'select-row\'>\
                    <td>#</td>\
                    <td>\
                        <p>'+item+'<br><i>'+description+'</i></p>\
                    </td>\
                    <td>'+cost+'</td>\
                    <td>'+qty+'</td>\
                    <td class=\'amount\'>'+amount+'</td>\
                    <td>\
                        <a  style="padding: 3px 6px;" class="del-btn  btn btn-default"><i class="bi bi-trash"></i></a>\
                        <a style="padding: 3px 6px; display: none;" class="up-btn btn btn-default"><span class="glyphicon glyphicon-menu-up"></span></a>\
                        <a style="padding: 3px 6px; display: none;" class="down-btn btn btn-default"><span class="glyphicon glyphicon-menu-down"></span></a>\
                        <input type="hidden" value=\''+qty+'\' name="Quotation[qty][]">\
                        <input type="hidden" value=\''+item+'\' name="Quotation[item][]">\
                        <input type="hidden" value=\''+description+'\' name="Quotation[description][]">\
                        <input type="hidden" value=\''+cost+'\' name="Quotation[price][]">\
                    </td>\
                </tr>';
                $(".item-input").val("");
                $(".description-input").val("");
                $(".cost-input").val("0");
                $(".qty-input").val("1");
                $(".content-table tr").eq(-5).after(tr);
                item_amount = parseFloat(item_amount) + parseFloat(amount);
                calculateDiscount();
            });

            $("#quotation-discount").keyup(function(){
                calculateDiscount();
            });
            $("#quotation-gst").keyup(function(){
                console.log("GST!");
                calculateGST();
            });

            $('body').click(function(){
                $(".select-row").css('background-color', 'white');
                $(".down-btn").css('display', 'none');
                $(".up-btn").css('display', 'none');
            });

            $(document).on("click",'.del-btn', function(e){
                item_amount -= Number($(this).parent().parent().find(".amount").html());
                calculateDiscount();
                $(this).parent().parent().remove();
            });
            $(document).on("click",'.down-btn', function(e){
                goDown($(this));
            });
            $(document).on("click",'.up-btn', function(e){
                goUp($(this));
            });
            $(document).on("click",'.select-row', function(e){
                $(".select-row").css('background-color', 'white');
                $(this).find(".down-btn").css('display', 'inline');
                $(this).find(".up-btn").css('display', 'inline');
                $(this).css('background-color', '#fff799');
                selected_ele = $(this);
            });
            $(document).keydown(function(e) {
                if(e.which == 38){
                    goUp($(selected_ele).find(".up-btn"));
                }
                if(e.which == 40){
                   goDown($(selected_ele).find(".down-btn"));
                }
                if (e.key == "Escape") { 
                    $(".down-btn").css('display', 'none');
                    $(".up-btn").css('display', 'none');
                    $(".select-row").css('background-color', 'white');
                } 
                
            });
            function goDown(ele){
                var index= $(ele).parent().parent().index();
                if(($(".content-table").children().children().last().index()-(index+1) > 3)){
                    $(ele).parent().parent().insertAfter($(ele).parent().parent().parent().find("tr").eq(index+1));
                }
            }
            function goUp(ele){
                var index= $(ele).parent().parent().index();
                if((index > 2)){
                    $(ele).parent().parent().insertBefore($(ele).parent().parent().parent().find("tr").eq(index-1));
                }
            }

            function calculateDiscount(){
                let discount = $("#quotation-discount").val();
                discount = discount / 100;
                discount_amount = parseFloat((discount * item_amount)).toFixed(2);
                $(".discount-value").html(discount_amount);
                $(".subtotal").html(parseFloat((item_amount - discount_amount)).toFixed(2));
                $(".total").html(parseFloat(((item_amount - discount_amount) + gst_amount)).toFixed(2));
                $(".total-input").val(parseFloat(((item_amount - discount_amount) + gst_amount)).toFixed(2));
                calculateGST();
            }

            function calculateGST(){
                let gst = parseFloat($("#quotation-gst").val());
                console.log(discount_amount);
                gst = gst / 100;
                gst_amount = parseFloat(((item_amount - discount_amount) * gst)).toFixed(2);
                console.log( gst_amount);
                $(".gst-value").html(gst_amount);
                $(".total").html(parseFloat((item_amount - discount_amount)+ Number(gst_amount)).toFixed(2));
                $(".total-input").val(parseFloat((item_amount - discount_amount)+ Number(gst_amount)).toFixed(2));
            }

            $('.panel-heading').next().hide();
            $(".panel-heading").click(function(){
                $(this).next().slideToggle();
            });
            $(".field-btn").click(function(){
                div = '<div class="row field-template">\
                        <div class="col-md-3">\
                            <p>Field Label\
                            <input type="text" name="Quotation[field_label][]" class="form-control">\
                            </p>\
                        </div>\
                        <div class="col-md-3">\
                            <p>Field Value\
                            <input type="text" name="Quotation[field_value][]" class="form-control">\
                            </p>\
                        </div>\
                        <div class="col-md-1 field-remove">\
                            <p><br>\
                                <a style="color: red;"  class="btn btn-default"><span class="glyphicon glyphicon-remove"></span></a>\
                            </p>\
                        </div>\
                    </div>';
                $(".fields").append(div);
            });
        });
        $(document).on("click",".field-remove", function(e){
            $(this).parent().remove();
        });
JS;
    $this->registerJS($script);
?>