<?php
use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $searchModel app\models\SearchInvoice */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Quotation';
$this->params['breadcrumbs'][] = $this->title;
?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
<div class="invoice-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <div class="row mb-3">
        <div class="col-md-6">
            <?php $form = ActiveForm::begin([
                'action' => ['index'], // Action for submitting the search form
                'method' => 'get',
                'options' => ['class' => 'form-inline'],
            ]); ?>
            <div class="input-group">
                <?= $form->field($searchModel, 'quotation_number')->textInput(['placeholder' => 'Search by quotation number', 'class' => 'form-control'])->label(false) ?>
                <div class="input-group-append">
                    <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
                </div>
            </div>
            <?php ActiveForm::end(); ?>
        </div>
        <div class="col-md-6 text-right">
            <?= Html::a('<i class="bi bi-plus"></i> New Quotation', ['create'], ['class' => 'btn btn-success']) ?>
        </div>
    </div>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'tableOptions' => ['class' => 'table table-striped table-bordered'],
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            'quotation_number',
            'quotation_date:date',
            'expiry_date',
            [
                'attribute' => 'client_name',
                'value' => 'client.companyname'
            ],
            
            [
                'class' => 'yii\grid\ActionColumn',
                'template' => '{view} {update} {delete}',
                'contentOptions' => ['class' => 'text-center'],
                'buttons' => [
                    'view' => function ($url, $model) {
                        return Html::a('<span class="bi bi-eye"></span>', ['view', 'id' => $model->quotation_id], ['class' => 'btn btn-info btn-sm', 'title' => 'View']);
                    },
                    'update' => function ($url, $model) {
                        return Html::a('<span class="bi bi-pencil"></span>', ['update', 'id' => $model->quotation_id], ['class' => 'btn btn-primary btn-sm', 'title' => 'Update']);
                    },
                    'delete' => function ($url, $model) {
                        return Html::a('<span class="bi bi-trash"></span>', ['delete', 'id' => $model->quotation_id], [
                            'class' => 'btn btn-danger btn-sm',
                            'title' => 'Delete',
                            'data' => [
                                'confirm' => 'Are you sure you want to delete this item?',
                                'method' => 'post',
                            ],
                        ]);
                    },
                ],
            ],
        ],
    ]); ?>

</div>
<style>
    /* Global styles */
body {
    font-family: Arial, sans-serif;
    background-color: #f8f9fa;
}

.invoice-index {
    padding: 20px;
    background-color: #ffffff;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

/* Form and button styles */
.form-control {
    width: 100%;
    border-radius: 0.25rem;
}

.btn {
    border-radius: 0.25rem;
}

.btn-primary {
    background-color: #007bff;
    border-color: #007bff;
}

.btn-primary:hover {
    background-color: #0056b3;
    border-color: #0056b3;
}

.btn-success {
    background-color: #28a745;
    border-color: #28a745;
}

.btn-success:hover {
    background-color: #218838;
    border-color: #218838;
}

.btn-info {
    background-color: #17a2b8;
    border-color: #17a2b8;
}

.btn-info:hover {
    background-color: #138496;
    border-color: #138496;
}

.btn-danger {
    background-color: #dc3545;
    border-color: #dc3545;
}

.btn-danger:hover {
    background-color: #c82333;
    border-color: #c82333;
}

/* Table styles */
.table {
    background-color: #ffffff;
}

.table th,
.table td {
    border: none;
}

.table-striped tbody tr:nth-of-type(odd) {
    background-color: rgba(0, 123, 255, 0.05);
}

.table-hover tbody tr:hover {
    background-color: rgba(0, 123, 255, 0.1);
}

.text-center {
    text-align: center;
}

.text-right {
    text-align: right;
}

</style>