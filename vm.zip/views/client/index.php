<?php

use yii\helpers\Html;
use yii\grid\GridView;
use app\models\Manager;

/* @var $this yii\web\View */
/* @var $searchModel app\models\SearchUsers */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Clients';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="users-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Create Clients', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'tableOptions' => ['class' => 'table table-striped table-bordered'], // Bootstrap table classes
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            'companyname',
            'email:email',
            'phonenumber',
            [
                'attribute' => 'manager_id',
                'value' => function ($model) {
                    return $model->manager ? $model->manager->name : 'N/A'; // Check if $model->manager exists
                },
                
            ],
            //'created_at',
            //'updated_at',
            [
                'attribute' => 'is_deleted',
                'label' => 'User Status',
                'format' => 'html',
                'value' => function ($model) {
                    $status = $model->is_deleted == 1 ? 'In Active' : 'Active';
                    $color = $model->is_deleted == 1 ? 'red' : 'green';
                    return '<span style="background-color: ' . $color . '; color: white; padding: 3px 6px; border-radius: 5px;">' . $status . '</span>';
                },
            ],
            [
                'class' => 'yii\grid\ActionColumn',
                'contentOptions' => ['style' => 'white-space: nowrap;'], // Prevent action column from wrapping
            ],
        ],
    ]); ?>

</div>
<style>
    /* Global styles */
body {
    font-family: Arial, sans-serif;
    background-color: #f8f9fa;
}

.invoice-index {
    padding: 20px;
    background-color: #ffffff;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

/* Form and button styles */
.form-control {
    width: 100%;
    border-radius: 0.25rem;
}

.btn {
    border-radius: 0.25rem;
}

.btn-primary {
    background-color: #007bff;
    border-color: #007bff;
}

.btn-primary:hover {
    background-color: #0056b3;
    border-color: #0056b3;
}

.btn-success {
    background-color: #28a745;
    border-color: #28a745;
}

.btn-success:hover {
    background-color: #218838;
    border-color: #218838;
}

.btn-info {
    background-color: #17a2b8;
    border-color: #17a2b8;
}

.btn-info:hover {
    background-color: #138496;
    border-color: #138496;
}

.btn-danger {
    background-color: #dc3545;
    border-color: #dc3545;
}

.btn-danger:hover {
    background-color: #c82333;
    border-color: #c82333;
}

/* Table styles */
.table {
    background-color: #ffffff;
}

.table th,
.table td {
    border: none;
}

.table-striped tbody tr:nth-of-type(odd) {
    background-color: rgba(0, 123, 255, 0.05);
}

.table-hover tbody tr:hover {
    background-color: rgba(0, 123, 255, 0.1);
}

.text-center {
    text-align: center;
}

.text-right {
    text-align: right;
}

</style>