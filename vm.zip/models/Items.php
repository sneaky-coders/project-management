<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "items".
 *
 * @property int $id
 * @property int|null $vendor_id
 * @property string $item_name
 * @property int $sku
 * @property float $cost_price
 * @property float $selling_price
 * @property int $unit_id
 * @property int $upc
 * @property int $ean
 * @property int $isbn
 * @property int $reorder_level
 * @property string $created_at
 * @property string $updated_at
 *
 * @property Vendor $vendor
 * @property Units $unit
 * @property PurchaseOrder[] $purchaseOrders
 * @property Stock[] $stocks
 */
class Items extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'items';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['vendor_id', 'sku', 'unit_id', 'upc', 'ean', 'isbn', 'reorder_level'], 'integer'],
            [['item_name', 'sku', 'cost_price', 'selling_price', 'unit_id', 'upc', 'ean', 'isbn', 'reorder_level'], 'required'],
            [['cost_price', 'selling_price'], 'number'],
            [['created_at', 'updated_at'], 'safe'],
            [['item_name'], 'string', 'max' => 100],
            [['vendor_id'], 'exist', 'skipOnError' => true, 'targetClass' => Vendor::className(), 'targetAttribute' => ['vendor_id' => 'vendor_id']],
            [['unit_id'], 'exist', 'skipOnError' => true, 'targetClass' => Units::className(), 'targetAttribute' => ['unit_id' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'vendor_id' => 'Vendor ID',
            'item_name' => 'Item Name',
            'sku' => 'Sku',
            'cost_price' => 'Cost Price',
            'selling_price' => 'Selling Price',
            'unit_id' => 'Unit ID',
            'upc' => 'Upc',
            'ean' => 'Ean',
            'isbn' => 'Isbn',
            'reorder_level' => 'Reorder Level',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * Gets query for [[Vendor]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getVendor()
    {
        return $this->hasOne(Vendor::className(), ['vendor_id' => 'vendor_id']);
    }

    /**
     * Gets query for [[Unit]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getUnit()
    {
        return $this->hasOne(Units::className(), ['id' => 'unit_id']);
    }

    /**
     * Gets query for [[PurchaseOrders]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getPurchaseOrders()
    {
        return $this->hasMany(PurchaseOrder::className(), ['item_id' => 'id']);
    }

    /**
     * Gets query for [[Stocks]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getStocks()
    {
        return $this->hasMany(Stock::className(), ['item_id' => 'id']);
    }
}
