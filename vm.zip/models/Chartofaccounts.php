<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "chartofaccounts".
 *
 * @property int $account_id
 * @property string $account_code
 * @property string $account_name
 * @property string $account_type
 * @property int|null $parent_id
 * @property string|null $description
 * @property int $is_active
 * @property string $created_at
 * @property string|null $updated_at
 *
 * @property Chartofaccounts $parent
 * @property Chartofaccounts[] $chartofaccounts
 */
class Chartofaccounts extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'chartofaccounts';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['account_code', 'account_name', 'account_type'], 'required'],
            [['account_type', 'description'], 'string'],
            [['parent_id', 'is_active'], 'integer'],
            [['created_at', 'updated_at'], 'safe'],
            [['account_code'], 'string', 'max' => 20],
            [['account_name'], 'string', 'max' => 100],
            [['parent_id'], 'exist', 'skipOnError' => true, 'targetClass' => Chartofaccounts::className(), 'targetAttribute' => ['parent_id' => 'account_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'account_id' => 'Account ID',
            'account_code' => 'Account Code',
            'account_name' => 'Account Name',
            'account_type' => 'Account Type',
            'parent_id' => 'Parent ID',
            'description' => 'Description',
            'is_active' => 'Is Active',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * Gets query for [[Parent]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getParent()
    {
        return $this->hasOne(Chartofaccounts::className(), ['account_id' => 'parent_id']);
    }

    /**
     * Gets query for [[Chartofaccounts]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getChartofaccounts()
    {
        return $this->hasMany(Chartofaccounts::className(), ['parent_id' => 'account_id']);
    }
}
