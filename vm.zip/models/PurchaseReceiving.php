<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "purchase_receiving".
 *
 * @property int $pr_id
 * @property int $purchase_id
 * @property int $received_qty
 * @property string $delivery_date
 * @property string $status
 * @property string $created_at
 * @property string|null $updated_at
 */
class PurchaseReceiving extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'purchase_receiving';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['purchase_id', 'received_qty', 'delivery_date', 'status'], 'required'],
            [['purchase_id', 'received_qty'], 'integer'],
            [['delivery_date', 'created_at', 'updated_at'], 'safe'],
            [['status'], 'string', 'max' => 100],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'pr_id' => 'Pr ID',
            'purchase_id' => 'Purchase ID',
            'received_qty' => 'Received Qty',
            'delivery_date' => 'Delivery Date',
            'status' => 'Status',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }
}
