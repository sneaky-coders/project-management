<?php

namespace app\controllers;

use Yii;
use app\models\Chartofaccounts;
use app\models\SearchChartofaccounts;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use app\models\Invoice;

/**
 * ChartsOfAccountsController implements the CRUD actions for Chartofaccounts model.
 */
class ChartsOfAccountsController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Chartofaccounts models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new SearchChartofaccounts();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    public function actionAccountReport()
{
    $model = new \app\models\Chartofaccounts();
    
    // Retrieve POST data
    $request = Yii::$app->request;
    $startDate = $request->post('start_date');
    $endDate = $request->post('end_date');

    // Validate and set default values for dates
    $startDate = $startDate ? date('Y-m-d', strtotime($startDate)) : '1970-01-01';
    $endDate = $endDate ? date('Y-m-d', strtotime($endDate)) : date('Y-m-d');

    // Debugging: Output the dates being used
    Yii::info("Filtering records from $startDate to $endDate", __METHOD__);

    // Build the query with BETWEEN clause
    $query = (new \yii\db\Query())
        ->select(['account_code', 'account_name', 'account_type', 'created_at', 'updated_at'])
        ->from('chartofaccounts')
        ->where(['between', 'created_at', $startDate . ' 00:00:00', $endDate . ' 23:59:59']);

    // Output the SQL query for debugging
    Yii::info($query->createCommand()->getRawSql(), __METHOD__);

    // Fetch the records
    $accounts = $query->all();

    // Calculate the total amount from the invoice table
    $totalAmountQuery = (new \yii\db\Query())
        ->select(['SUM(total) as total_amount'])
        ->from('invoice')
        ->where(['between', 'invoice_date', $startDate . ' 00:00:00', $endDate . ' 23:59:59']);
    
    // Fetch the total amount
    $totalAmountResult = $totalAmountQuery->one();
    $totalAmount = $totalAmountResult['total_amount'] ?? 0;

    // Prepare data for the pie chart
    $chartData = [];
    foreach ($accounts as $account) {
        $chartData[] = [
            'label' => $account['account_name'],
            'value' => 0 // Placeholder; update according to actual data structure
        ];
    }

    return $this->render('account-report', [
        'model' => $model,
        'accounts' => $accounts,
        'startDate' => $startDate,
        'endDate' => $endDate,
        'totalAmount' => $totalAmount,
        'chartData' => json_encode($chartData),
    ]);
}


    /**
     * Displays a single Chartofaccounts model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Chartofaccounts model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Chartofaccounts();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->account_id]);
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Chartofaccounts model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->account_id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Chartofaccounts model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }
    public function actionReport()
    {
        $chartOfAccounts = Chartofaccounts::find()->all();
        $invoices = Invoice::find()->all();

        return $this->render('report', [
            'chartOfAccounts' => $chartOfAccounts,
            'invoices' => $invoices,
        ]);
    }

    /**
     * Finds the Chartofaccounts model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Chartofaccounts the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Chartofaccounts::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
