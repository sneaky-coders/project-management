<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Customer */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="customer-form">
    <?php $form = ActiveForm::begin([
        'options' => ['class' => 'modern-form'],
        'fieldConfig' => [
            'template' => "{label}\n<div class=\"input-group\">{input}</div>\n{error}",
            'labelOptions' => ['class' => 'form-label'],
            'inputOptions' => ['class' => 'form-control'],
            'errorOptions' => ['class' => 'error'],
        ],
    ]); ?>

    <h2 class="form-title">Customer Details</h2>

    <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'email')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'contact')->textInput() ?>

    <?= $form->field($model, 'address')->textarea(['rows' => 4]) ?>

    <?= $form->field($model, 'created_at')->hiddenInput()->label(false) ?>

    <?= $form->field($model, 'updated_at')->hiddenInput()->label(false) ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>
</div>

<style>
/* styles.css */

/* Container for the form */
.customer-form {
    width: 100%; /* Full-width container */
    max-width: 800px; /* Maximum width for larger screens */
    margin: 0 auto;
    padding: 30px;
    background-color: #f9f9f9;
    border: 1px solid #eee;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

/* Form title */
.form-title {
    font-size: 24px;
    margin-bottom: 20px;
    text-align: center;
}

/* Label styles */
.form-label {
    font-weight: bold;
    margin-bottom: 8px;
    display: block;
}

/* Input styles */
.form-control {
    padding: 12px;
    font-size: 14px;
    border: 1px solid #ddd;
    border-radius: 4px;
    transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    width: 100%; /* Full-width input */
}

.input-group {
    position: relative;
}

/* Error message styles */
.error {
    color: #dc3545;
    font-size: 13px;
    margin-top: 4px;
}

/* Submit button */
.btn-primary {
    background-color: #007bff;
    border-color: #007bff;
    color: #fff;
    padding: 12px 20px; /* Larger padding horizontally */
    font-size: 16px;
    border-radius: 4px;
}

.btn-primary:hover {
    background-color: #0056b3;
    border-color: #0056b3;
}
</style>
