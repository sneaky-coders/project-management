<?php
use yii\helpers\Html;

// Define CSS styles for the PDF
$css = "
    body { font-family: Arial, sans-serif; }
    table { width: 100%; border-collapse: collapse; border: 1px solid #ddd; }
    th, td { border: 1px solid #ddd; padding: 8px; }
    th { background-color: #f2f2f2; }
    .success { background-color: #d4edda; }
    .warning { background-color: #fff3cd; }
    .text-center { text-align: center; }
    .company-header { font-size: 24px; margin-bottom: 20px; }
";

// Register the CSS styles with mPDF
$this->registerCss($css);

// Calculate total amount based on filtered data
$totalFilteredAmount = 0;
foreach ($dataProvider->getModels() as $model) {
    $totalFilteredAmount += $model->total;
}
?>
<style>
    td,th
    {
        border:2px solid black;
    }
</style>

<h1 class="company-header">Kankonkar Technologies Pvt Ltd</h1>

<!-- Display total amount filtered -->
<p><strong>Total Amount:</strong> INR <?= Yii::$app->formatter->asDecimal($totalFilteredAmount) ?></p>

<table class="table table-bordered" style="border:2px solid black">
    <thead>
        <tr>
            <th class="text-center">Sr. No</th>
            <th class="text-center">Invoice Number</th>
            <th class="text-center">Invoice Date</th>
            <th class="text-center">Company Name</th>
            <th class="text-center">Total Amount</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($dataProvider->getModels() as $key => $model): ?>
            <tr class="<?= $model->payment_status == 1 ? 'success' : 'warning' ?>">
                <td class="text-center"><?= $key + 1 ?></td>
                <td><?= Html::encode($model->invoice_number) ?></td>
                <td><?= date('d M Y', strtotime($model->invoice_date)) ?></td>
                <td><?= Html::encode($model->client->companyname ?? 'Null') ?></td>
                <td class="text-right"><?= Html::encode($model->total) ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
