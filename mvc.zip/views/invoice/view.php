<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Invoice */

$this->title = "Invoice - " . $model->invoice_number;
$this->params['breadcrumbs'][] = ['label' => 'Invoices', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

// Register Bootstrap Icons
$this->registerCssFile('https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css');
?>
<style>
    .invoice-view {
        background-color: #fff;
        border: 1px solid #ddd;
        border-radius: 5px;
        padding: 20px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        color: #333;
    }

    .invoice-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }

    .invoice-title {
        font-size: 24px;
        font-weight: bold;
        color: #333;
    }

    .invoice-status {
        padding: 8px 15px;
        border-radius: 20px;
        text-transform: uppercase;
        font-size: 14px;
        font-weight: bold;
    }

    .alert-success {
        background-color: #d4edda;
        color: #155724;
        border-color: #c3e6cb;
    }

    .alert-warning {
        background-color: #fff3cd;
        color: #856404;
        border-color: #ffeeba;
    }

    .text-right {
        text-align: right;
    }

    .btn-action {
        padding: 8px 15px;
        margin-bottom: 10px;
    }

    .btn-update {
        background-color: #007bff;
        color: #fff;
        border: none;
    }

    .btn-update:hover {
        background-color: #0056b3;
        color: #fff;
    }

    .btn-print {
        background-color: #17a2b8;
        color: #fff;
        border: none;
    }

    .btn-print:hover {
        background-color: #117a8b;
        color: #fff;
    }

    .invoice-table {
        margin-top: 20px;
        font-size: 14px;
    }

    .invoice-table th,
    .invoice-table td {
        vertical-align: middle;
        border: 1px solid #ddd;
        padding: 8px;
    }

    .total-row td {
        font-weight: bold;
        background-color: #f8f9fa;
    }

    .additional-fields {
        margin-top: 20px;
    }

    .additional-fields p {
        font-weight: bold;
        margin-bottom: 10px;
    }

    .list-group-item {
        border: none;
    }

    .print-settings {
        margin-top: 20px;
    }
</style>

<div class="invoice-view">
    <div class="invoice-header">
        <div class="invoice-title"><?= Html::encode($this->title) ?></div>
        <?php if ($model->payment_status == 1) : ?>
            <div class="invoice-status alert alert-success">Paid</div>
        <?php else : ?>
            <div class="invoice-status alert alert-warning">Pending</div>
        <?php endif; ?>
    </div>

    <div class="text-right">
        <?= Html::a('<i class="bi bi-pencil"></i> Update', ['update', 'id' => $model->invoice_id], ['class' => 'btn btn-outline-primary btn-action btn-update']) ?>
        <?= Html::a('<i class="bi bi-print"></i> Print Preview', ['print', 'id' => $model->invoice_id, 'layout' => 'layout1'], ['class' => 'btn btn-primary btn-action btn-print']) ?>
    </div>

    <?= DetailView::widget([
        'model' => $model,
        'options' => ['class' => 'table table-bordered invoice-table'],
        'attributes' => [
            'invoice_number',
            'invoice_date',
            [
                'label' => 'GST',
                'value' => function ($model) {
                    return $model->gst . "%";
                },
            ],
            [
                'label' => 'Discount',
                'value' => function ($model) {
                    return $model->discount . "%";
                },
            ],
            [
                'label' => 'Payment Status',
                'value' => function ($model) {
                    return $model->payment_status == 1 ? "Paid" : "Not Paid";
                }
            ],
            'client.companyname',
        ],
    ]) ?>

    <table class="table table-bordered invoice-table">
        <thead>
            <tr>
                <th>Sr. No</th>
                <th>Content</th>
                <th>Unit Price</th>
                <th>Qty</th>
                <th>Amount</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $subtotal = 0;
            $model->content = json_decode($model->content);
            $sr_no = 1;
            $discount_amount = 0;
            $gst_amount = 0;
            if (is_array($model->content)) {
                foreach ($model->content as $key => $value) {
                    if (is_numeric($value[2]) && is_numeric($value[3])) {
                        $subtotal += $value[2] * $value[3];
                    }
                    ?>
                    <tr>
                        <td><?= $sr_no ?></td>
                        <td>
                            <p><?= $value[0] ?> <br><i><?= $value[1] ?></i></p>
                        </td>
                        <td><?= $value[2] ?></td>
                        <td><?= $value[3] ?></td>
                        <td><?= is_numeric($value[2]) && is_numeric($value[3]) ? $value[2] * $value[3] : 0 ?></td>
                    </tr>
                    <?php
                    $sr_no++;
                }
            }
            ?>
            <tr class="total-row">
                <td colspan="4"><b>Subtotal</b></td>
                <td><?= $subtotal ?></td>
            </tr>
            <?php if ($model->discount != "" && $model->discount != 0) : ?>
                <?php $discount_amount = $subtotal * ($model->discount / 100); ?>
                <tr>
                    <td colspan="4"><b>Discount (<?= $model->discount . "%" ?>)</b></td>
                    <td><?= $discount_amount ?></td>
                </tr>
            <?php endif; ?>
            <?php if ($model->discount != "" && $model->discount != 0) : ?>
                <?php $subtotal -= $discount_amount; ?>
                <tr class="total-row">
                    <td colspan="4"><b>Subtotal after discount</b></td>
                    <td><?= $subtotal ?></td>
                </tr>
            <?php endif; ?>
            <?php if ($model->gst != "" && $model->gst != 0) : ?>
                <?php $gst_amount = $subtotal * ($model->gst / 100); ?>
                <tr>
                    <td colspan="4"><b>GST (<?= $model->gst . "%" ?>)</b></td>
                    <td><?= $gst_amount ?></td>
                </tr>
            <?php endif; ?>
            <tr class="total-row">
                <td colspan="4"><b>TOTAL</b></td>
                <td><?= $subtotal + $gst_amount ?></td>
            </tr>
        </tbody>
    </table>



    
</div>
