<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\Departments;

/* @var $this yii\web\View */
/* @var $model app\models\Employees */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="employees-form">
    <?php $form = ActiveForm::begin(); ?>

    <div class="row">
        <div class="col-md-6">
            <?= $form->field($model, 'first_name')->textInput(['maxlength' => true])->label('First Name') ?>
        </div>
        <div class="col-md-6">
            <?= $form->field($model, 'last_name')->textInput(['maxlength' => true])->label('Last Name') ?>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <?= $form->field($model, 'email')->textInput(['maxlength' => true])->label('Email') ?>
        </div>
        <div class="col-md-6">
            <?= $form->field($model, 'phone')->textInput(['maxlength' => true])->label('Phone') ?>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <?= $form->field($model, 'address')->textInput(['maxlength' => true])->label('Address') ?>
        </div>
        <div class="col-md-6">
            <?= $form->field($model, 'birth_date')->widget(\yii\jui\DatePicker::class, [
                'options' => ['class' => 'form-control'],
                'dateFormat' => 'yyyy-MM-dd', // Set the format of the date
            ])->label('Birth Date') ?>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <?= $form->field($model, 'hire_date')->widget(\yii\jui\DatePicker::class, [
                'options' => ['class' => 'form-control'],
                'dateFormat' => 'yyyy-MM-dd', // Set the format of the date
            ])->label('Hire Date') ?>
        </div>
        <div class="col-md-6">
            <?= $form->field($model, 'department_id')->dropDownList(
                \yii\helpers\ArrayHelper::map(Departments::find()->all(), 'id', 'name'),
                ['prompt' => 'Select Department']
            )->label('Department') ?>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <?= $form->field($model, 'salary')->textInput(['maxlength' => true])->label('Salary') ?>
        </div>
        <div class="col-md-6">
            <?= $form->field($model, 'aadhar')->textInput(['maxlength' => true])->label('Aadhar') ?>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <?= $form->field($model, 'pan')->textInput(['maxlength' => true])->label('PAN') ?>
        </div>
    </div>

    <div class="form-group">
        <div class="col-md-12">
            <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
        </div>
    </div>

    <?php ActiveForm::end(); ?>
</div>
<style>
    /* Style for the form container */
    .employees-form {
        background-color: #f9f9f9;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    /* Style for form headers */
    h2 {
        margin-bottom: 15px;
        color: #333;
    }

    /* Style for input fields */
    .form-control {
        border-radius: 5px;
        border-color: #ccc;
    }

    /* Style for labels */
    .control-label {
        font-weight: bold;
    }

    /* Style for error messages */
    .help-block {
        color: #dc3545;
        margin-top: 5px;
    }

    /* Style for submit button */
    .btn-success {
        background-color: #28a745;
        border-color: #28a745;
        color: #fff;
        border-radius: 5px;
    }

    /* Hover effect for submit button */
    .btn-success:hover {
        background-color: #218838;
        border-color: #218838;
    }

    /* Style for form groups */
    .form-group {
        margin-bottom: 20px;
    }
</style>