<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use app\models\Vendor;
use app\models\Units; // Assuming Unit model namespace

/* @var $this yii\web\View */
/* @var $model app\models\Items */
/* @var $form yii\widgets\ActiveForm */

$this->title = 'Create Item';

?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h1 class="card-title"><?= Html::encode($this->title) ?></h1>

                    <?php $form = ActiveForm::begin([
                        'options' => ['class' => 'modern-form'],
                    ]); ?>

                    <?= $form->field($model, 'vendor_id')->dropDownList(
                        ArrayHelper::map(Vendor::find()->all(), 'vendor_id', 'name'),
                        ['prompt' => 'Select Vendor']
                    )->label('Vendor') ?>

                    <?= $form->field($model, 'unit_id')->dropDownList(
                        ArrayHelper::map(Units::find()->all(), 'id', 'name'),
                        ['prompt' => 'Select Unit']
                    )->label('Unit') ?>

                    <?= $form->field($model, 'item_name')->textInput(['maxlength' => true])->label('Item Name') ?>

                    <?= $form->field($model, 'sku')->textInput()->label('SKU') ?>

                    <?= $form->field($model, 'cost_price')->textInput()->label('Cost Price') ?>

                    <?= $form->field($model, 'selling_price')->textInput()->label('Selling Price') ?>

                    <?= $form->field($model, 'upc')->textInput()->label('UPC') ?>

                    <?= $form->field($model, 'ean')->textInput()->label('EAN') ?>

                    <?= $form->field($model, 'isbn')->textInput()->label('ISBN') ?>

                    <?= $form->field($model, 'reorder_level')->textInput()->label('Reorder Level') ?>

                    <div class="form-group">
                        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
                    </div>

                    <?php ActiveForm::end(); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Custom styles */
.container {
    margin-top: 50px;
}

.card {
    border: none;
    border-radius: 8px;
    background-color: #fff;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
}

.card-title {
    font-size: 2rem;
    margin-bottom: 1.5rem;
    font-weight: 600;
    color: #333;
}

.form-group {
    margin-bottom: 2rem;
}

.control-label {
    font-weight: bold;
    color: #666;
}

.modern-form .form-control {
    border: 1px solid #ccc;
    border-radius: 5px;
    transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}

.modern-form .form-control:focus {
    border-color: #6cb2eb;
    outline: 0;
    box-shadow: 0 0 0 0.2rem rgba(108, 178, 235, 0.25);
}

.btn-success {
    background-color: #6cb2eb;
    border-color: #6cb2eb;
    font-weight: bold;
    padding: 0.75rem 1.5rem;
    transition: background-color 0.15s ease-in-out, border-color 0.15s ease-in-out;
}

.btn-success:hover {
    background-color: #4c92cc;
    border-color: #4c92cc;
}

/* Adjustments for form fields */
.form-group.field-items-unit_id,
.form-group.field-items-vendor_id {
    margin-bottom: 2rem; /* Adjust margin for dropdown fields */
}

.form-group.field-items-unit_id select,
.form-group.field-items-vendor_id select {
    width: 100%;
    height: calc(2.25rem + 2px);
    padding: 0.375rem 0.75rem;
    font-size: 1rem;
    line-height: 1.5;
    color: #495057;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    border-radius: 0.25rem;
    transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}

.form-group.field-items-unit_id select:focus,
.form-group.field-items-vendor_id select:focus {
    border-color: #6cb2eb;
    outline: 0;
    box-shadow: 0 0 0 0.2rem rgba(108, 178, 235, 0.25);
}
</style>
