<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\ArrayHelper; // Add this line

/* @var $this yii\web\View */
/* @var $searchModel app\models\SearchPurchaseOrder */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Purchase Orders';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="purchase-order-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Create Purchase Order', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'], // Adds a serial number column

            // Display vendor name instead of ID
            [
                'attribute' => 'vendor_id',
                'value' => function($model) {
                    return isset($model->vendor) ? $model->vendor->name : 'N/A';
                },
                'label' => 'Vendor Name', // Label for the column header
            ],

            'po_number', // Display the Purchase Order number

            'reference', // Display the reference

            'po_date', // Display the PO date

            'delivery_date',
            'payment_terms',

            // Display the items as a comma-separated list
            [
                'attribute' => 'item_id',
                'value' => function($model) {
                    $items = $model->items;
                    if (empty($items)) {
                        return 'N/A';
                    }
                    $itemNames = ArrayHelper::getColumn($items, 'item_name');
                    return implode(', ', $itemNames);
                },
                'label' => 'Items', // Label for the column header
            ],

            [
                'attribute' => 'unit_id',
                'value' => function($model) {
                    return isset($model->unit) ? $model->unit->name : 'N/A';
                },
                'label' => 'Unit', // Label for the column header
            ],

            'qty',

            ['class' => 'yii\grid\ActionColumn'], // Action column with edit and delete buttons
        ],
    ]); ?>

</div>

<!-- Include styles -->
<style>
    /* Global styles */
    body {
        font-family: Arial, sans-serif;
        background-color: #f8f9fa;
    }

    .purchase-order-index {
        padding: 20px;
        background-color: #ffffff;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    /* Form and button styles */
    .form-control {
        width: 100%;
        border-radius: 0.25rem;
    }

    .btn {
        border-radius: 0.25rem;
    }

    .btn-primary {
        background-color: #007bff;
        border-color: #007bff;
    }

    .btn-primary:hover {
        background-color: #0056b3;
        border-color: #0056b3;
    }

    .btn-success {
        background-color: #28a745;
        border-color: #28a745;
    }

    .btn-success:hover {
        background-color: #218838;
        border-color: #218838;
    }

    .btn-info {
        background-color: #17a2b8;
        border-color: #17a2b8;
    }

    .btn-info:hover {
        background-color: #138496;
        border-color: #138496;
    }

    .btn-danger {
        background-color: #dc3545;
        border-color: #dc3545;
    }

    .btn-danger:hover {
        background-color: #c82333;
        border-color: #c82333;
    }

    /* Table styles */
    .table {
        background-color: #ffffff;
    }

    .table th,
    .table td {
        border: none;
    }

    .table-striped tbody tr:nth-of-type(odd) {
        background-color: rgba(0, 123, 255, 0.05);
    }

    .table-hover tbody tr:hover {
        background-color: rgba(0, 123, 255, 0.1);
    }

    .text-center {
        text-align: center;
    }

    .text-right {
        text-align: right;
    }

    /* Pagination Styles */
    .pagination {
        display: flex;
        justify-content: center;
        padding: 0;
        margin: 20px 0;
    }

    .pagination li {
        display: inline;
    }

    .pagination li a, .pagination li span {
        color: #007bff;
        border: 1px solid #dee2e6;
        padding: 0.5rem 0.75rem;
        margin: 0 0.25rem;
        text-decoration: none;
        border-radius: 0.25rem;
        transition: background-color 0.3s ease, border-color 0.3s ease, color 0.3s ease;
    }

    .pagination li a:hover {
        background-color: #0056b3;
        color: #fff;
        border-color: #0056b3;
    }

    .pagination li.active span {
        background-color: #007bff;
        color: #fff;
        border-color: #007bff;
    }

    .pagination li.disabled span {
        color: #6c757d;
        border-color: #dee2e6;
    }
</style>
