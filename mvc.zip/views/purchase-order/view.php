<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\PurchaseOrder */

$this->title = 'Purchase Order Bill';
$this->params['breadcrumbs'][] = ['label' => 'Purchase Orders', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);

// Initialize variables
$items = $model->getItems();
$gstRate = 0.18;
$subtotal = 0;

?>

<div class="purchase-order-bill">

    <h1 class="text-center"><?= Html::encode($this->title) ?></h1>

    <div class="info-grid">
        <!-- Company Details -->
        <div class="info-item">
            <h2>Company Details</h2>
            <p>
                <strong>Company Name:</strong> Company Name<br>
                <strong>Company Address:</strong> Company Address<br>
                <strong>Company Phone:</strong> Company Phone<br>
                <strong>Company Email:</strong> Company Email<br>
                <strong>Company GSTIN:</strong> Company GSTIN<br>
            </p>
        </div>

        <!-- Vendor Information -->
        <div class="info-item">
            <h2>Vendor Information</h2>
            <p>
                <strong>Vendor Name:</strong> <?= Html::encode($model->vendor->name) ?><br>
                <strong>Vendor Phone:</strong> <?= Html::encode($model->vendor->contact) ?><br>
                <strong>PAN:</strong> <?= Html::encode($model->vendor->pan) ?><br>
                <strong>GSTIN:</strong> <?= Html::encode($model->vendor->gstin) ?><br>
            </p>
        </div>

        <!-- Purchase Order Details -->
        <div class="info-item">
            <h2>Purchase Order Details</h2>
            <p>
                <strong>PO Number:</strong> <?= Html::encode($model->po_number) ?><br>
                <strong>Reference:</strong> <?= Html::encode($model->reference) ?><br>
                <strong>PO Date:</strong> <?= Html::encode($model->po_date) ?><br>
                <strong>Delivery Date:</strong> <?= Html::encode($model->delivery_date) ?><br>
                <strong>Payment Terms:</strong> <?= Html::encode($model->payment_terms) ?><br>
            </p>
        </div>

        <!-- Ship To and Received By -->
        <div class="info-item">
            <h2>Shipping & Receiving</h2>
            <p>
                <strong>Ship To:</strong><br>
                Ship To Address<br>
                Ship To City, State, ZIP<br>
                <br>
                <strong>Received By:</strong><br>
                Receiver Name<br>
            </p>
        </div>
    </div>

    <div class="bill-items">
        <h2>Itemized List</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Item Name</th>
                    <th>Unit</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php $itemNumber = 1; ?>
                <?php foreach ($items as $item): ?>
                    <?php
                    $itemPrice = $item->selling_price;
                    $quantity = $model->qty; // Assuming quantity is the same for all items
                    $itemSubtotal = $itemPrice * $quantity;
                    $subtotal += $itemSubtotal;
                    ?>
                    <tr>
                        <td><?= $itemNumber++ ?></td>
                        <td><?= Html::encode($item->item_name) ?></td>
                        <td><?= Html::encode($item->unit->name) // Ensure unit information is accurate ?></td>
                        <td><?= Html::encode(number_format($itemPrice, 2)) ?></td>
                        <td><?= Html::encode($quantity) ?></td>
                        <td><?= Html::encode(number_format($itemSubtotal, 2)) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <?php
    $gstAmount = $subtotal * $gstRate;
    $total = $subtotal + $gstAmount;
    ?>

    <div class="bill-footer">
        <h3>Summary</h3>
        <p>
            <strong>Subtotal:</strong> <?= Html::encode(number_format($subtotal, 2)) ?><br>
            <strong>GST (18%):</strong> <?= Html::encode(number_format($gstAmount, 2)) ?><br>
            <strong>Total:</strong> <?= Html::encode(number_format($total, 2)) ?><br>
        </p>
        <?= Html::button('Print', [
            'class' => 'btn btn-success',
            'onclick' => 'window.print()'
        ]) ?>
    </div>
</div>

<style>
.purchase-order-bill {
    margin: 20px;
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 8px;
    background-color: #ffffff;
}

h1, h2, h3 {
    margin: 0;
    color: #333;
}

.info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 20px;
    margin-bottom: 20px;
}

.info-item {
    padding: 15px;
    border: 1px solid #ddd;
    border-radius: 4px;
    background-color: #f9f9f9;
}

.info-item h2 {
    margin-top: 0;
    background-color: #f0f0f0;
    padding: 10px;
    border-bottom: 1px solid #ddd;
    color: #333;
}

.bill-items table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}

.bill-items table, .bill-items th, .bill-items td {
    border: 1px solid #ddd;
}

.bill-items th, .bill-items td {
    padding: 10px;
    text-align: left;
}

.bill-footer {
    text-align: right;
    font-size: 1.2em;
}

.bill-footer .btn {
    margin-top: 10px;
}

@media print {
    .btn {
        display: none;
    }
    .purchase-order-bill {
        margin: 0;
        padding: 0;
        border: none;
        background-color: transparent;
    }
    .info-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 0;
    }
    .info-item {
        border: 1px solid #ddd;
        background-color: #ffffff;
        padding: 10px;
        margin: 0;
    }
    .info-item h2 {
        background-color: #f0f0f0;
        border-bottom: 1px solid #ddd;
        padding: 8px;
    }
    .bill-items table, .bill-items th, .bill-items td {
        border: 1px solid #ddd;
    }
}
</style>
