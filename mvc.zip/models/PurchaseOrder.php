<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;

/**
 * This is the model class for table "purchase_order".
 *
 * @property int $po_id
 * @property int $vendor_id
 * @property string $po_number
 * @property string $reference
 * @property string $po_date
 * @property string $delivery_date
 * @property string $payment_terms
 * @property string $item_id
 * @property int $unit_id
 * @property int $qty
 */
class PurchaseOrder extends ActiveRecord
{
    public static function tableName()
    {
        return 'purchase_order';
    }

    public function rules()
    {
        return [
            [['vendor_id', 'po_number', 'reference', 'po_date', 'delivery_date', 'payment_terms', 'item_id', 'unit_id', 'qty'], 'required'],
            [['vendor_id', 'unit_id', 'qty'], 'integer'],
            [['po_date', 'delivery_date'], 'safe'],
            [['payment_terms'], 'string'],
            [['item_id'], 'string'],
            [['po_number'], 'string', 'max' => 50],
            [['reference'], 'string', 'max' => 100],
        ];
    }

    public function attributeLabels()
    {
        return [
            'po_id' => 'PO ID',
            'vendor_id' => 'Vendor ID',
            'po_number' => 'PO Number',
            'reference' => 'Reference',
            'po_date' => 'PO Date',
            'delivery_date' => 'Delivery Date',
            'payment_terms' => 'Payment Terms',
            'item_id' => 'Item ID',
            'unit_id' => 'Unit ID',
            'qty' => 'Quantity',
        ];
    }

    // Ensure the `item_id` attribute is stored as JSON in your database and use json_encode / json_decode
public function setItemIds(array $itemIds)
{
    $this->item_id = json_encode($itemIds); // Convert array to JSON string
}

public function getItemIds()
{
    return json_decode($this->item_id, true); // Convert JSON string to array
}

public function getItems()
{
    $itemIds = $this->getItemIds(); // Get item IDs as an array
    return Items::find()->where(['id' => $itemIds])->all(); // Retrieve items by IDs
}


    public function getVendor()
    {
        return $this->hasOne(Vendor::className(), ['vendor_id' => 'vendor_id']);
    }

    public function getUnit()
    {
        return $this->hasOne(Units::className(), ['id' => 'unit_id']);
    }


}
