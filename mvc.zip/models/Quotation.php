<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "quotation".
 *
 * @property int $quotation_id
 * @property string $quotation_number
 * @property string $quotation_date
 * @property string $expiry_date
 * @property float|null $gst
 * @property float|null $discount
 * @property string|null $content
 * @property string|null $quotation_option
 * @property string|null $additional_fields
 * @property string|null $notes
 * @property int|null $client_id
 * @property int|null $user_id
 * @property string|null $currency
 * @property float|null $total
 */
class Quotation extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'quotation';
    }

    /**
     * {@inheritdoc}
     */

     public $qty;
     public $item;
     public $description;
     public $price;
     public $field_label;
     public $field_value;
     public $print_setting;
    
    public function rules()
    {
        return [
     
          
            
            [[ 'client_id', 'quotation_date', 'expiry_date'], 'required'],
            [['quotation_date','expiry_date', 'created_at', 'updated_at', 'quotation_number', 'user_id', 'quotation_id'], 'safe'],
            [['qty', 'item', 'description', 'price', 'field_label', 'field_value', 'print_setting'], 'safe'],
            [[ 'client_id'], 'integer'],
            [['gst', 'discount', 'total'], 'number'],
            [['content', 'quotation_option', 'additional_fields'], 'string'],
            [['quotation_number', 'currency'], 'string', 'max' => 20],
            [['client_id'], 'exist', 'skipOnError' => true, 'targetClass' => Client::className(), 'targetAttribute' => ['client_id' => 'client_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'quotation_id' => 'Quotation ID',
            'quotation_number' => 'Quotation Number',
            'quotation_date' => 'Quotation Date',
            'expiry_date' => 'Expiry Date',
            'gst' => 'Gst',
            'discount' => 'Discount',
            'content' => 'Content',
            'quotation_option' => 'Quotation Option',
            'additional_fields' => 'Additional Fields',
            'notes' => 'Notes',
            'client_id' => 'Client ID',
            'user_id' => 'User ID',
            'currency' => 'Currency',
            'total' => 'Total',
        ];
    }
    public function getClient()
    {
        return $this->hasOne(Client::className(), ['client_id' => 'client_id']);
    }
}
