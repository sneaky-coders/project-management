<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;

/**
 * This is the model class for table "employee".
 *
 * @property int $id
 * @property string $emp_id
 * @property int $user_id
 * @property string $name
 * @property string $email
 * @property string $phone
 * @property string $address
 * @property string $birth_date
 * @property string $hire_dated
 * @property int $department_id
 * @property string $aadhar
 * @property string $pan
 * @property string $gender
 * @property string $designation
 * @property int $allowed_leaves
 * @property int $basic_and_da
 * @property int $hra
 * @property int $overtime
 * @property int $contribution_to_pf
 * @property int $esic
 * @property int $lwf
 * @property int $salary_advance
 * @property string $authorised_signatory
 * @property string $account_no
 * @property int $pf_applicable
 * @property int $medical_bill_submited
 * @property int $is_deleted
 * @property string $created_at
 * @property string $updated_at
 */
class Employee extends ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'employee';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['emp_id', 'name', 'gender', 'designation', 'allowed_leaves', 'basic_and_da', 'hra', 'overtime', 'contribution_to_pf', 'esic', 'lwf', 'email', 'phone', 'address', 'birth_date', 'hire_dated', 'department_id', 'aadhar', 'pan', 'salary_advance', 'authorised_signatory', 'account_no'], 'required'],
            [['user_id', 'allowed_leaves', 'basic_and_da', 'hra', 'overtime', 'contribution_to_pf', 'esic', 'lwf', 'phone', 'department_id', 'aadhar', 'salary_advance', 'pf_applicable', 'medical_bill_submited', 'is_deleted'], 'integer'],
            [['birth_date', 'hire_dated', 'created_at', 'updated_at'], 'safe'],
            [['emp_id', 'designation', 'address'], 'string', 'max' => 100],
            [['name', 'email', 'authorised_signatory'], 'string', 'max' => 50],
            [['gender', 'pan'], 'string', 'max' => 20],
            [['email'], 'unique'],
            [['aadhar'], 'string', 'length' => 12],
            [['aadhar'], 'match', 'pattern' => '/^\d{12}$/'],
            [['pan'], 'string', 'length' => 10],
            [['pan'], 'match', 'pattern' => '/^(?=.*[a-zA-Z])[a-zA-Z0-9]*$/'],
            [['account_no'], 'string', 'max' => 15],
            [['phone'], 'string', 'length' => 10],
            [['phone'], 'match', 'pattern' => '/^\d{10}$/'],
            [['birth_date'], 'date', 'format' => 'yyyy-MM-dd', 'max' => date('Y-m-d'), 'tooBig' => 'Birth date cannot exceed current date.'],
            [['birth_date'], 'date', 'format' => 'yyyy-MM-dd', 'min' => date('Y-m-d', strtotime('-90 years')), 'tooSmall' => 'Age cannot be more than 90 years.'],
            [['hire_dated'], 'date', 'format' => 'yyyy-MM-dd', 'max' => date('Y-m-d'), 'tooBig' => 'Hiring date cannot exceed current date.'],
            [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => Users::class, 'targetAttribute' => ['user_id' => 'user_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'emp_id' => 'Employee ID',
            'user_id' => 'User ID',
            'name' => 'Name',
            'email' => 'Email',
            'phone' => 'Phone',
            'address' => 'Address',
            'birth_date' => 'Birth Date',
            'hire_dated' => 'Hire Date',
            'department_id' => 'Department ID',
            'aadhar' => 'Aadhar',
            'pan' => 'PAN',
            'gender' => 'Gender',
            'designation' => 'Designation',
            'allowed_leaves' => 'Allowed Leaves',
            'basic_and_da' => 'Basic and DA',
            'hra' => 'HRA',
            'overtime' => 'Overtime',
            'contribution_to_pf' => 'Contribution to PF',
            'esic' => 'ESIC',
            'lwf' => 'LWF',
            'salary_advance' => 'Salary Advance',
            'authorised_signatory' => 'Authorised Signatory',
            'account_no' => 'Account No',
            'pf_applicable' => 'PF Applicable',
            'medical_bill_submited' => 'Medical Bill Submitted',
            'is_deleted' => 'Is Deleted',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }



    /**
     * Gets query for [[User]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(Users::class, ['user_id' => 'user_id']);
    }

    /**
     * Gets query for [[LeaveRequests]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getLeaveRequests()
    {
        return $this->hasMany(LeaveRequests::class, ['employee_id' => 'id']);
    }

    /**
     * Gets query for [[Salaries]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getSalaries()
    {
        return $this->hasMany(Salary::class, ['employee_id' => 'id']);
    }
}
