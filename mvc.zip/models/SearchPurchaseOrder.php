<?php

namespace app\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\PurchaseOrder;

/**
 * SearchPurchaseOrder represents the model behind the search form of `app\models\PurchaseOrder`.
 */
class SearchPurchaseOrder extends PurchaseOrder
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['po_id', 'vendor_id', 'item_id', 'unit_id', 'qty'], 'integer'],
            [['po_number', 'reference', 'po_date', 'delivery_date', 'payment_terms', 'created_at', 'updated_at'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = PurchaseOrder::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'po_id' => $this->po_id,
            'vendor_id' => $this->vendor_id,
            'po_date' => $this->po_date,
            'delivery_date' => $this->delivery_date,
            'item_id' => $this->item_id,
            'unit_id' => $this->unit_id,
            'qty' => $this->qty,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ]);

        $query->andFilterWhere(['like', 'po_number', $this->po_number])
            ->andFilterWhere(['like', 'reference', $this->reference])
            ->andFilterWhere(['like', 'payment_terms', $this->payment_terms]);

        return $dataProvider;
    }
}
