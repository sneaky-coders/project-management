<?php

namespace app\controllers;

use Yii;
use app\models\PurchaseOrder;
use app\models\SearchPurchaseOrder;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use app\models\Items;

class PurchaseOrderController extends Controller
{
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    public function actionIndex()
    {
        $searchModel = new SearchPurchaseOrder();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }
    public function actionCreate()
    {
        $model = new PurchaseOrder();
    
        if ($model->load(Yii::$app->request->post())) {
            $itemIds = Yii::$app->request->post('PurchaseOrder')['item_id'] ?? '';
            $itemIdsArray = json_decode($itemIds, true); // Convert JSON string to array
            $model->setItemIds($itemIdsArray); // Set item IDs
    
            if ($model->save()) {
                return $this->redirect(['view', 'id' => $model->po_id]);
            }
        }
    
        return $this->render('create', [
            'model' => $model,
        ]);
    }
    
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);
    
        if ($model->load(Yii::$app->request->post())) {
            $itemIds = Yii::$app->request->post('PurchaseOrder')['item_id'] ?? '';
            $itemIdsArray = json_decode($itemIds, true); // Convert JSON string to array
            $model->setItemIds($itemIdsArray); // Set item IDs
    
            if ($model->save()) {
                return $this->redirect(['view', 'id' => $model->po_id]);
            }
        }
    
        return $this->render('update', [
            'model' => $model,
        ]);
    }
    
    public function actionBill($id)
    {
        $model = PurchaseOrder::findOne($id);

        if ($model === null) {
            throw new NotFoundHttpException('The requested page does not exist.');
        }

        return $this->render('bill', [
            'model' => $model,
        ]);
    }

    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    protected function findModel($id)
    {
        if (($model = PurchaseOrder::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }

    public function actionGetItemsByVendor($vendor_id)
    {
        Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;

        if (!is_numeric($vendor_id)) {
            return $this->asJson(['error' => 'Invalid vendor_id']);
        }

        $items = Items::find()->where(['vendor_id' => $vendor_id])->all();
        if (empty($items)) {
            return $this->asJson(['error' => 'No items found for the selected vendor']);
        }

        $itemList = [];
        foreach ($items as $item) {
            $itemList[] = [
                'id' => $item->id,
                'name' => $item->item_name,
                'sku' => $item->sku,
                'cost_price' => $item->cost_price,
                'selling_price' => $item->selling_price,
                'unit_id' => $item->unit_id,
                'upc' => $item->upc,
                'ean' => $item->ean,
                'isbn' => $item->isbn,
                'reorder_level' => $item->reorder_level,
            ];
        }

        return $this->asJson($itemList);
    }
}
