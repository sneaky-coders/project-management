<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use app\models\Vendor;
use app\models\Ingredients;
use Yii;

/* @var $this yii\web\View */
/* @var $model app\models\Purchase */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="purchase-form">
    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'vendor_id')->dropDownList(
        ArrayHelper::map(Vendor::find()->all(), 'vendor_id', 'name'),
        ['prompt' => 'Select Vendor']
    ) ?>

 

    <div id="items-container">
        <div class="item-row">
            <div class="row">
                <div class="col-md-3">
               

                </div>
                <div class="col-md-2">
                    <?= $form->field($model, 'item')->textInput(['maxlength' => true])->label('Item ') ?>
                </div>
                <div class="col-md-2">
                    <?= $form->field($model, 'hsn')->textInput(['class' => 'form-control qty'])->label('HSN') ?>
                </div>
                <div class="col-md-2">
                <?= $form->field($model, 'paymentstatus')->dropDownList(
    ['Pending' => 'Pending', 'Paid' => 'Paid', 'Overdue' => 'Overdue'],
    ['prompt' => 'Select Payment Status']
)->label('Payment Status') ?>

                </div>
                <div class="col-md-3">
                    <?= $form->field($model, 'amount')->textInput([ 'class' => 'form-control rate'])->label('Amount ') ?>
                </div>
            </div>
            
        </div>
    </div>



    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>
</div>


