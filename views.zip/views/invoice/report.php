<?php

use yii\helpers\Html;
use yii\helpers\ArrayHelper;
use yii\widgets\ActiveForm;
use yii\data\ActiveDataProvider;
use app\models\Invoice;

$this->title = "Invoice Report";
?>
<?php $form = ActiveForm::begin([
    'method' => 'get',
]); ?>
<input type="hidden" name="_csrf" value="<?=Yii::$app->request->getCsrfToken()?>" />
<div class="row">
    <div class="col-md-3">
        <?= Html::input('date', 'start_date', Yii::$app->request->get('start_date'), ['class' => 'form-control', 'placeholder' => 'Start Date']) ?>
    </div>
    <div class="col-md-3">
        <?= Html::input('date', 'end_date', Yii::$app->request->get('end_date'), ['class' => 'form-control', 'placeholder' => 'End Date']) ?>
    </div>
    <div class="col-md-2">
        <?= Html::dropDownList('payment_status', Yii::$app->request->get('payment_status'), ['1' => 'Paid', '0' => 'Not Paid'], ['class' => 'form-control', 'prompt' => 'Select payment status ...']) ?>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <?= Html::submitButton('Filter', ['class' => 'btn btn-default']) ?>
        </div>
    </div>
</div>
<?php ActiveForm::end(); ?>

<table class="table table-bordered">
    <tr>
        <th>Sr. No</th>
        <th>Invoice Number</th>
        <th>Invoice Date</th>
        <th>Client Name</th>
        <th>Total Amount</th>
        <th>Action</th>
    </tr>
    <?php
    $total = 0;
    $models = $dataProvider->getModels();
    foreach ($models as $key => $model) {
        $contents = json_decode($model->content);
        $subtotal = 0;
        foreach ($contents as $content) {
            $subtotal += $content[2] * $content[3];
        }
        $total += $subtotal;
        $class = $model->payment_status == 1 ? 'success' : 'warning';
        echo '<tr class="'. $class .'">
                <td>'. ($key + 1) .'</td>
                <td>'. $model->invoice_number .'</td>
                <td>'. date('d M Y', strtotime($model->invoice_date)) .'</td>
                <td>'. $model->client->companyname .'</td>
               
                <td>'.  $model->total  .'</td>
                <td><a href="index.php?r=invoice%2Fview&amp;id='. $model->invoice_id .'"><span class="glyphicon glyphicon-eye-open"></span></a></td>
            </tr>';
    }
    ?>
</table>

<?php 
$overall = Invoice::find()->sum('total');

?>
<p><b>Total Amount: </b> INR <?= $overall ?></p>
