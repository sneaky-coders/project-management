<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Users */
/* @var $form yii\widgets\ActiveForm */
?>

<style>

.custom-file-input {
    color: transparent;
    cursor: pointer;
    display: inline-block;
    position: relative;
    overflow: hidden;
}

.custom-file-input input[type="file"] {
    font-size: 100px;
    position: absolute;
    top: 0;
    right: 0;
    opacity: 0;
    cursor: pointer;
}

.custom-file-input::before {
    content: 'Choose File';
    color: #ffffff; /* Text color */
    background-color: #007bff; /* Background color */
    border-color: #007bff; /* Border color */
    display: inline-block;
    padding: 8px 20px;
    border-radius: 5px;
    cursor: pointer;
}

.custom-file-input:hover::before {
    background-color: #0056b3; /* Hover background color */
    border-color: #0056b3; /* Hover border color */
}

.custom-file-input:active::before {
    background-color: #004380; /* Active background color */
    border-color: #004380; /* Active border color */
}


</style>

<div class="users-form">

    <?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data', 'class' => 'form-horizontal']]); ?>

    <?= $form->field($model, 'username')->textInput(['maxlength' => true, 'class' => 'form-control']) ?>

    <?= $form->field($model, 'fullname')->textInput(['maxlength' => true, 'class' => 'form-control']) ?>

    <?= $form->field($model, 'password')->passwordInput(['maxlength' => true, 'class' => 'form-control']) ?>

    <?= $form->field($model, 'image')->fileInput() ?>
    <label class="custom-file-label" for="customFile">Choose file</label>

    <?= $form->field($model, 'email')->textInput(['maxlength' => true, 'class' => 'form-control']) ?>

    <?= $form->field($model, 'level')->dropDownList(['1' => 'Admin', '2' => 'Staff'], ['class' => 'form-control']) ?>

    <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
            <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
        </div>
    </div>

    <?php ActiveForm::end(); ?>

</div>
