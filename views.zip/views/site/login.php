<?php
/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \common\models\LoginForm */

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;

$this->title = 'Login';
$this->params['breadcrumbs'][] = $this->title;
?>

<style>
    .app-main__inner
    {
        background-color:#f1f4f6;
    }

    body
    {
        background-image: url('../bg.jpg'); /* Replace 'path/to/your/image.jpg' with the actual path to your image */
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        background-attachment: fixed;
    }

    
    .login-form {
        max-width: 400px;
        margin: 0 auto;
        padding: 20px;
        background-color: #f7f7f7;
        border-radius: 5px;
        box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
        margin-right:530px;
    }

    .login-form h2 {
        text-align: center;
        margin-bottom: 20px;
    }

    .login-form .form-group {
        margin-bottom: 20px;
    }

    .login-form .forgot-password {
        text-align: right;
    }

    .login-form .btn-login {
        width: 100%;
    }
</style>

<div class="login-form">
    <h2><?= Html::encode($this->title) ?></h2>

    <?php $form = ActiveForm::begin(['id' => 'login-form']); ?>

    <?= $form->field($model, 'username')->textInput(['placeholder' => 'Email', 'class' => 'form-control']) ?>

    <?= $form->field($model, 'password')->passwordInput(['placeholder' => 'Password', 'class' => 'form-control']) ?>

    <div class="form-group">
        <?= Html::submitButton('Login', ['class' => 'btn btn-primary btn-login', 'name' => 'login-button']) ?>
    </div>

    <div class="forgot-password">
        <?= Html::a('Forgot password', '#') ?>
    </div>

    <?php ActiveForm::end(); ?>
</div>
