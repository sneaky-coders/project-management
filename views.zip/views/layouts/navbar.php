<?php if (!Yii::$app->user->isGuest): ?>
<div class="app-header header-shadow">
    <div class="app-header__logo">
        <div style="font-size: 24px; font-weight: bold;">
            <a href="<?= Yii::$app->urlManager->createUrl(['site/index']) ?>">Anklyticx ERP</a>
        </div>
        <div class="header__pane ml-auto">
            <div>
                <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                    <span class="hamburger-box">
                        <span class="hamburger-inner"></span>
                    </span>
                </button>
            </div>
        </div>
    </div>
    <div class="app-header__mobile-menu">
        <div>
            <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                <span class="hamburger-box">
                    <span class="hamburger-inner"></span>
                </span>
            </button>
        </div>
    </div>
    <div class="app-header__menu">
        <span>
            <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                <span class="btn-icon-wrapper">
                    <i class="fa fa-ellipsis-v fa-w-6"></i>
                </span>
            </button>
        </span>
    </div>
    <div class="app-header__content">
        <div class="app-header-right">
            <div class="header-btn-lg pr-0">
                <div class="widget-content p-0">
                    <div class="widget-content-wrapper">
                        <div class="widget-content-left mr-3">
                            <img width="42" class="rounded-circle" src="<?= Yii::$app->request->baseUrl ?>/images/avatars/icon.png" alt="">
                        </div>
                        <div class="widget-content-left">
                            <div class="widget-heading">
                                <span class="d-block"><?= Yii::$app->user->identity->username; ?></span>
                                <span class="text-muted"><?= Yii::$app->user->identity->email; ?></span>
                            </div>
                        </div>
                        <div class="widget-content-right header-user-info ml-3">
                            <div class="btn-group">
                                <button type="button" class="btn btn-icon btn-primary" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="fa fa-angle-down"></i>
                                </button>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <form id="logout-form" action="<?= Yii::$app->urlManager->createUrl(['site/logout']) ?>" method="POST" style="display: none;">
                                        <input type="hidden" name="<?= Yii::$app->request->csrfParam ?>" value="<?= Yii::$app->request->csrfToken ?>">
                                    </form>
                                    <a href="<?= Yii::$app->urlManager->createUrl(['users/profile']) ?>" class="dropdown-item">
                                        <i class="fas fa-user"></i> Profile
                                    </a>
                                    <a href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="dropdown-item">
                                        <i class="fas fa-sign-out-alt"></i> Log out
                                    </a>
                                    <a href="<?= Yii::$app->urlManager->createUrl(['users/change-password']) ?>" class="dropdown-item">
                                        <i class="fas fa-key"></i> Change Password
                                    </a>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
