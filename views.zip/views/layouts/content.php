<?php
/* @var $content string */

// use yii\bootstrap4\Breadcrumbs;
?>
<div class="content-wrapper">
    <!-- Main content -->
    <div class="content">
        <?= $content ?><!-- /.container-fluid -->
    </div>
</div>