<?php
use app\models\Users;
?>
<div class="app-sidebar sidebar-shadow <?php echo Yii::$app->user->isGuest ? 'd-none' : ''; ?>">
    <div class="app-header__logo">
        <!-- <div class="logo-src"></div> -->
        <div style="font-size: 24px;font-weight:bold">Anklyticx ERP</div>
        <div class="header__pane ml-auto">
            <div>
                <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                    <span class="hamburger-box">
                        <span class="hamburger-inner"></span>
                    </span>
                </button>
            </div>
        </div>
    </div>
    <div class="app-header__mobile-menu">
        <div>
            <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                <span class="hamburger-box">
                    <span class="hamburger-inner"></span>
                </span>
            </button>
        </div>
    </div>
    <div class="app-header__menu">
        <span>
            <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                <span class="btn-icon-wrapper">
                    <i class="fa fa-ellipsis-v fa-w-6"></i>
                </span>
            </button>
        </span>
    </div>
    <div class="scrollbar-sidebar">
        <div class="app-sidebar__inner">
            <ul class="vertical-nav-menu">
                <?php
                if (!Yii::$app->user->isGuest) { // Check if the user is not a guest
                ?>
                <!-- Sidebar items go here -->
                <li class="app-sidebar__heading">Dashboard</li>
                <li>
                    <a href="index.php?r=site/index">
                        <i class="metismenu-icon pe-7s-users"></i>
                        Home
                    </a>
                </li>

                <li class="app-sidebar__heading">Settings</li>
                <li>
                    <a href="#">
                        <i class="metismenu-icon pe-7s-settings"></i>
                        Configuration
                        <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
                    </a>
                    <ul>
                        <li>
                            <a href="index.php?r=users/index">
                                <i class="metismenu-icon"></i>
                                Users
                            </a>
                        </li>

                    </ul>
                    <ul>
                        <li>
                            <a href="index.php?r=client/index">
                                <i class="metismenu-icon"></i>
                                Clients
                            </a>
                        </li>

                    </ul>
                    <ul>
                        <li>
                            <a href="index.php?r=manager/index">
                                <i class="metismenu-icon"></i>
                                Managers
                            </a>
                        </li>

                    </ul>
                    <ul>
                        <li>
                            <a href="index.php?r=vendor/index">
                                <i class="metismenu-icon"></i>
                                Vendors
                            </a>
                        </li>

                    </ul>
                </li>
                <li class="app-sidebar__heading">Billing</li>
                <li>
                    <a href="#">
                        <i class="metismenu-icon pe-7s-cash"></i>
                        Cash Flow
                        <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
                    </a>
                    <ul>
                        <li>
                            <a href="index.php?r=invoice/index">
                                <i class="metismenu-icon"></i>
                                Invoice
                            </a>
                        </li>

                    </ul>
                    <ul>
                        <li>
                            <a href="index.php?r=purchase/index">
                                <i class="metismenu-icon"></i>
                                Purchase Bill
                            </a>
                        </li>

                    </ul>
                  
                </li>

                <li class="app-sidebar__heading">Reports</li>
                <li>
                    <a href="#">
                        <i class="metismenu-icon pe-7s-graph"></i>
                        Reports
                        <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
                    </a>
                    <ul>
                        <li>
                            <a href="index.php?r=invoice/report">
                                <i class="metismenu-icon"></i>
                                Invoice Reports
                            </a>
                        </li>

                    </ul>
                   
                  
                </li>
                <!-- More Links-->
                
                   
                  
                </li>
                <!-- Add more sidebar items as needed -->
                <?php } ?>
            </ul>
        </div>
    </div>
</div>
