<?php

use app\assets\AppAsset;
use yii\helpers\Url;
use app\widgets\Alert;
use yii\bootstrap4\Breadcrumbs;
use yii\bootstrap4\Html;
/* @var $this yii\web\View */

AppAsset::register($this);
app\assets\AppAsset::register($this);
$this->title = 'Wedding App';
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!--
    =========================================================
    * ArchitectUI HTML Theme Dashboard - v1.0.0
    =========================================================
    * Product Page: https://dashboardpack.com
    * Copyright 2019 DashboardPack (https://dashboardpack.com)
    * Licensed under MIT (https://github.com/DashboardPack/architectui-html-theme-free/blob/master/LICENSE)
    =========================================================
    * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
    -->
    <!-- <script type="text/javascript" src="<? //= Yii::$app->request->baseUrl 
                                                ?>/scripts/main.js"></script> -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php $this->registerCsrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
    <!-- <link href="<? //= Yii::$app->request->baseUrl 
                        ?>/css/demo.css" rel="stylesheet"> -->
    <style>
        * {
            font-family: 'Lato', sans-serif;
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
</head>

<body style="background-color:#fff">
    <?php $this->beginBody() ?>

    <!-- <?//= $this->render('header') ?> -->

    <?= $content ?>


    </div>
    <!-- <script src="https://code.jquery.com/jquery-3.6.0.slim.min.js"
        integrity="sha256-u7e5khyithlIdTpu22PHhENmPcRdFiHRjhAuHcs05RI=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
        crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/10976fa26c.js" crossorigin="anonymous"></script>
    <script src="./js/scroll-out.min.js"></script>
    <script src="./js/header.js"></script> -->
    <script type="text/javascript">
        ScrollOut({
            targets: 'div'
        })
    </script>

    <?php $this->endBody() ?>
</body>

<?php $this->endPage() ?>