<!-- _manager_details.php -->
<h4><?= $manager->name ?></h4>
<p>Email: <?= $manager->email ?></p>
<p>Contact: <?= $manager->contact ?></p>
<p>Address: <?= $manager->address ?></p>
