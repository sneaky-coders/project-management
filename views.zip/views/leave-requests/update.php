<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\LeaveTypes; // Import the LeaveTypes model if needed
use app\models\Employees;

/* @var $this yii\web\View */
/* @var $model app\models\LeaveRequests */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="leave-requests-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'employee_id')->dropDownList(
        \yii\helpers\ArrayHelper::map(Employees::find()->all(), 'id', function($model) {
            return $model->first_name . ' ' . $model->last_name;
        }),
        ['prompt' => 'Select Employee']
    ) ?>

    <?= $form->field($model, 'leave_type_id')->dropDownList(
        \yii\helpers\ArrayHelper::map(LeaveTypes::find()->all(), 'id', 'name'),
        ['prompt' => 'Select Leave Type']
    ) ?>

    <?= $form->field($model, 'start_date')->textInput(['type' => 'date']) ?>

    <?= $form->field($model, 'end_date')->textInput(['type' => 'date']) ?>

    <?= $form->field($model, 'status')->dropDownList(
        ['pending' => 'Pending', 'approved' => 'Approved', 'rejected' => 'Rejected'],
        ['prompt' => 'Select Status']
    ) ?>

    <?= $form->field($model, 'reason')->textarea(['rows' => 6]) ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
