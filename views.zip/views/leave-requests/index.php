<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ActiveForm;
use app\models\Employees; // Import the Employees model
use app\models\LeaveTypes; // Import the LeaveTypes model

/* @var $this yii\web\View */
/* @var $searchModel app\models\SearchLeaveRequests */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Leave Requests';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="leave-requests-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Create Leave Requests', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
    'dataProvider' => $dataProvider,
    'rowOptions' => function ($model, $key, $index, $grid) {
        if ($model->status === 'pending') {
            return ['class' => 'warning'];
        }
    },
    'columns' => [
        ['class' => 'yii\grid\SerialColumn'],
        'id',
        [
            'attribute' => 'employee_id',
            'value' => function ($model) {
                $employee = Employees::findOne($model->employee_id);
                return $employee ? $employee->first_name . ' ' . $employee->last_name : '';
            },
        ],
        [
            'attribute' => 'leave_type_id',
            'value' => function ($model) {
                $leaveType = LeaveTypes::findOne($model->leave_type_id);
                return $leaveType ? $leaveType->name : '';
            },
        ],
        'start_date',
        'end_date',
        [
            'attribute' => 'status',
            'format' => 'raw',
            'value' => function ($model) {
                $form = ActiveForm::begin(['action' => ['update', 'id' => $model->id], 'method' => 'post']);
                $statusDropdown = Html::activeDropDownList($model, 'status', ['pending' => 'Pending', 'approved' => 'Approved', 'rejected' => 'Rejected'], ['class' => 'form-control']);
                $submitBtn = Html::submitButton('Update', ['class' => 'btn btn-primary']);
                ActiveForm::end();
                return $statusDropdown;
            },
        ],
        'reason:ntext',
        [
            'class' => 'yii\grid\ActionColumn',
            'template' => '{update}',
            'urlCreator' => function ($action, $model, $key, $index) {
                return ['update', 'id' => $model->id];
            },
        ],
    ],
]); ?>
