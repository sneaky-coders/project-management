<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;
use yii\web\IdentityInterface;

use app\models\LoginLog;

class Users extends ActiveRecord implements IdentityInterface
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'users';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['username', 'fullname', 'password', 'email', 'level', 'image'], 'required'],
            [['username'], 'unique'],
            [['email'], 'unique'],
            [['level', 'is_deleted'], 'integer'],
            [['created_at', 'updated_at'], 'safe'],
            [['username', 'fullname','image'], 'string', 'max' => 100],
            [['email'], 'email'],
            ['password', 'string', 'min' => 8], // Minimum length of 8 characters
            ['password', 'validatePasswordComplexity'], // Custom validation for password complexity
        ];
    }

    public function validatePasswordComplexity($attribute, $params)
{
    if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/', $this->$attribute)) {
        $this->addError($attribute, 'Password must contain at least one uppercase letter, one lowercase letter, and one digit.');
    }
}

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'user_id' => 'User ID',
            'username' => 'Username',
            'fullname' => 'Full Name',
            'password' => 'Password',
            'Image' => 'Image',
            'email' => 'Email',
            'level' => 'Level',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'is_deleted' => 'Is Deleted',
        ];
    }

    /**
     * Finds an identity by the given ID.
     * @param string|int $id the ID to be looked for
     * @return IdentityInterface|null the identity object that matches the given ID.
     */
    public static function findIdentity($id)
    {
        return static::findOne($id);
    }

    /**
     * Finds an identity by the given token.
     * @param string $token the token to be looked for
     * @param mixed $type the type of the token. The value of this parameter depends on the implementation.
     * For example, it can be an access token or a refresh token.
     * @return IdentityInterface|null the identity object that matches the given token.
     */
    public static function findIdentityByAccessToken($token, $type = null)
    {
        // Implement this method according to your application's logic
        return null;
    }

    /**
     * {@inheritdoc}
     */
    public function getId()
    {
        return $this->user_id;
    }

    /**
     * {@inheritdoc}
     */
    public function getAuthKey()
    {
        return null;
    }

    /**
     * {@inheritdoc}
     */
    public function validateAuthKey($authKey)
    {
        return null;
    }

    /**
     * Finds user by username.
     * @param string $username
     * @return static|null
     */
    public static function findByUsername($username)
    {
        return static::findOne(['username' => $username]);
    }

    /**
     * Validates password.
     * @param string $password
     * @return bool if password provided is valid for current user
     */
    public function validatePassword($password)
    {
        return Yii::$app->security->validatePassword($password, $this->password);
    }

    
    public function afterLogin($event)
    {
        Yii::info('After login event triggered.', 'app\models\Users');

        // Create a new LoginLog instance
        $loginLog = new LoginLog();

        // Set the attributes for the LoginLog record
        $loginLog->user_id = $this->id; // Assuming user_id is stored in the Users model as 'id'
        $loginLog->login_time = date('Y-m-d H:i:s'); // Current login time
        $loginLog->ip_address = Yii::$app->request->userIP; // User's IP address
        $loginLog->user_agent = Yii::$app->request->userAgent; // User's user agent

        Yii::info('Login log attributes set.', 'app\models\Users');

        // Save the LoginLog record
        if ($loginLog->save()) {
            Yii::info('Login log saved successfully.', 'app\models\Users');
        } else {
            Yii::error('Error saving login log: ' . print_r($loginLog->errors, true), 'app\models\Users');
        }
    }
    
    public function getLoginLogs()
    {
        return $this->hasMany(LoginLog::className(), ['user_id' => 'user_id']);
    }
    
}
