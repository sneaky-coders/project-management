<?php

namespace app\controllers;

use Yii;
use app\models\Manager;
use app\models\SearchManager;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\Response;
use yii\data\ActiveDataProvider;

/**
 * ManagerController implements the CRUD actions for Manager model.
 */
class ManagerController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Manager models.
     * @return mixed
     */
    public function actionIndex()
{
    if (!Yii::$app->user->isGuest) {
        $level = Yii::$app->user->identity->level;
        $searchModel = new SearchManager();
        $query = Manager::find();

        // Include deleted records for users with level 1
        if ($level == 1) {
            $query->where(['is_deleted' => [0, 1]]);
        } else {
            $query->where(['is_deleted' => 0]);
        }

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => [
                'defaultOrder' => [],
            ],
        ]);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'level' => $level,
        ]);
    }

    return $this->redirect(['/site/index']);
}
    public function actionGetDetails($managerId)
    {
        if (!Yii::$app->user->isGuest) {
            Yii::$app->response->format = Response::FORMAT_JSON;
        
        $manager = Manager::findOne($managerId);
        if ($manager) {
            return $this->renderAjax('_manager_details', [
                'manager' => $manager,
            ]);
        } else {
            return ['error' => 'Manager not found'];
        }    
        }
        else
        {
            return $this->redirect(['/site/login']);
        }
        
    }

    /**
     * Displays a single Manager model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        if (!Yii::$app->user->isGuest) {
            return $this->render('view', [
                'model' => $this->findModel($id),
            ]);    
        }
        else
        {
            return $this->redirect(['/site/login']);
        }
        
    }

    /**
     * Creates a new Manager model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        if (!Yii::$app->user->isGuest) {
            $model = new Manager();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->manager_id]);
        }

        return $this->render('create', [
            'model' => $model,
        ]);    
        }
        else
        {
            return $this->redirect(['/site/login']);
        }
        
    }

    /**
     * Updates an existing Manager model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        if (!Yii::$app->user->isGuest) {
            $model = $this->findModel($id);

            if ($model->load(Yii::$app->request->post()) && $model->save()) {
                return $this->redirect(['view', 'id' => $model->manager_id]);
            }
    
            return $this->render('update', [
                'model' => $model,
            ]);      
        }
        else
        {
            return $this->redirect(['/site/login']);
        }
      
    }

    /**
     * Deletes an existing Manager model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        if (!Yii::$app->user->isGuest) {
            $model = $this->findModel($id);
            $model->is_deleted = 1;
            $model->save(false); // Save without validation
        
            return $this->redirect(['index']);
        }
        else
        {
            return $this->redirect(['/site/login']);
        }
       
    }

    /**
     * Finds the Manager model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Manager the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Manager::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
